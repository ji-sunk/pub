const hamburger = document.querySelector(".hamburger");
const leftMenu1 = document.querySelector(".leftMenu1");
const leftMenu2 = document.querySelector(".leftMenu2");
// const Logo = document.querySelector(".logo");
const leftMenuList = document.querySelector(".leftMenuList");
const dropdownItems = document.querySelectorAll('.dropdown');

hamburger.addEventListener('click', () => {
  leftMenuList.classList.toggle('active');
  leftMenu1.classList.toggle("openMenu");
  hamburger.classList.toggle("open");
  closeAllDropdowns();
});

hamburger.addEventListener('click', () => {
  leftMenuList.classList.toggle('active');
  leftMenu2.classList.toggle("openMenu");
  closeAllDropdowns();
});

dropdownItems.forEach(item => {
  item.addEventListener('click', () => {
    item.classList.toggle('active');
  });
});

function closeAllDropdowns() {
  dropdownItems.forEach(item => {
    item.classList.remove('active');
  });
}




