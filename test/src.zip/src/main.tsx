import React from "react";
import ReactDOM from "react-dom/client";
// import "../public/assets/styles/bzp/bzp_globals.css";
// import "../public/assets/styles/bzp/bzp_variable.css";
import "../public/assets/styles/hyd_globals.css";
import "../public/assets/styles/hyd_variable.css";

import App from "./App.tsx";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
