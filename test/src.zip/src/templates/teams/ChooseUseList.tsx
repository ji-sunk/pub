import StarRateRoundedIcon from "@mui/icons-material/StarRateRounded";
import {
  Box,
  Checkbox,
  ToggleButton,
  IconButton,
  Chip,
} from "@mui/material";
import { Link } from "react-router-dom";
import { useGridApiRef } from "@mui/x-data-grid-premium";
import * as React from "react";
import { useState } from "react";

interface Row {
  id: number;
  path: string[];
}

const ChooseUseList = () => {
  const [checked, setChecked] = useState(false);
  // radio
  const [RadioValue02, setRadioValue02] = useState("radio02-01");
  const handleChangeRadio02 = (event) => {
    setRadioValue02(event.target.value);
  };
  /* Toggle 버튼 */
  const [selected, setSelected] = React.useState(false);
  return (
    <>
      <ul className="ui-box des-cir-search">
        <li>
          <Box className="inner-label">
            <Chip
              label="카페"
              size="small"
              variant="outlined"
              className="bp-chip type-radius"
              clickable
            />
            <div className="title bp-ellipsis2">우주라이크커피양정점</div>
            <div className="bookmark-area">
              <ToggleButton
                value="button"
                selected={selected}
                onChange={() => {
                  setSelected(!selected);
                }}
                className="btn-icon-toggle icon-bookmark"
              >
                <StarRateRoundedIcon fontSize="medium" />
              </ToggleButton>
            </div>
          </Box>
          <div className="txt-box inner">
            <Link className="tel-num inner-sides" to="tel:052-1234-5678">
                052-1234-5678
                <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-phone.svg" alt="전화" />
              </IconButton>
            </Link>
            <div className="address inner-sides">
              울산광역시 동구 방어진순환도로 911 1층
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-copy.svg" alt="복사" />
              </IconButton>
            </div>
            <div className="dd-txt inner-sides">
              $목적지명$부터의 거리
              <span className="km">1.5Km</span>
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-location.svg" alt="목적지" />
              </IconButton>
            </div>
          </div>
        </li>

        <li>
          <Box className="inner-label">
            <Chip
              label="카페"
              size="small"
              variant="outlined"
              className="bp-chip type-radius"
              clickable
            />
            <div className="title bp-ellipsis2">우주라이크커피양정점 최대 2줄까지 타이틀 적용 우주라이크커피양정점 최대 2줄까지 타이틀 적용</div>
            <div className="bookmark-area">
              <ToggleButton
                value="button"
                selected={selected}
                onChange={() => {
                  setSelected(!selected);
                }}
                className="btn-icon-toggle icon-bookmark"
              >
                <StarRateRoundedIcon fontSize="medium" />
              </ToggleButton>
            </div>
          </Box>
          <div className="txt-box inner">
            <Link className="tel-num inner-sides" to="tel:052-1234-5678">
                052-1234-5678
                <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-phone.svg" alt="전화" />
              </IconButton>
            </Link>
            <div className="address inner-sides">
              울산광역시 동구 방어진순환도로 911 1층 울산광역시 동구 방어진순환도로 911 1층울산광역시 동구 방어진순환도로 911 1층
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-copy.svg" alt="복사" />
              </IconButton>
            </div>
            <div className="dd-txt inner-sides">
              $목적지명$부터의 거리
              <span className="km">1.5Km</span>
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-location.svg" alt="목적지" />
              </IconButton>
            </div>
          </div>
        </li>

        <li>
          <Box className="inner-label">
            <Chip
              label="카페"
              size="small"
              variant="outlined"
              className="bp-chip type-radius"
              clickable
            />
            <div className="title bp-ellipsis2">우주라이크커피양정점 최대 2줄까지 타이틀 적용 우주라이크커피양정점 최대 2줄까지 타이틀 적용</div>
            <div className="bookmark-area">
              <ToggleButton
                value="button"
                selected={selected}
                onChange={() => {
                  setSelected(!selected);
                }}
                className="btn-icon-toggle icon-bookmark"
              >
                <StarRateRoundedIcon fontSize="medium" />
              </ToggleButton>
            </div>
          </Box>
          <div className="txt-box inner">
            <Link className="tel-num inner-sides" to="tel:052-1234-5678">
                052-1234-5678
                <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-phone.svg" alt="전화" />
              </IconButton>
            </Link>
            <div className="address inner-sides">
              울산광역시 동구 방어진순환도로 911 1층 울산광역시 동구 방어진순환도로 911 1층울산광역시 동구 방어진순환도로 911 1층
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-copy.svg" alt="복사" />
              </IconButton>
            </div>
            <div className="dd-txt inner-sides">
              $목적지명$부터의 거리
              <span className="km">1.5Km</span>
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-location.svg" alt="목적지" />
              </IconButton>
            </div>
          </div>
        </li>

        <li>
          <Box className="inner-label">
            <Chip
              label="카페"
              size="small"
              variant="outlined"
              className="bp-chip type-radius"
              clickable
            />
            <div className="title bp-ellipsis2">우주라이크커피양정점 최대 2줄까지 타이틀 적용 우주라이크커피양정점 최대 2줄까지 타이틀 적용</div>
            <div className="bookmark-area">
              <ToggleButton
                value="button"
                selected={selected}
                onChange={() => {
                  setSelected(!selected);
                }}
                className="btn-icon-toggle icon-bookmark"
              >
                <StarRateRoundedIcon fontSize="medium" />
              </ToggleButton>
            </div>
          </Box>
          <div className="txt-box inner">
            <Link className="tel-num inner-sides" to="tel:052-1234-5678">
                052-1234-5678
                <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-phone.svg" alt="전화" />
              </IconButton>
            </Link>
            <div className="address inner-sides">
              울산광역시 동구 방어진순환도로 911 1층 울산광역시 동구 방어진순환도로 911 1층울산광역시 동구 방어진순환도로 911 1층
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-copy.svg" alt="복사" />
              </IconButton>
            </div>
            <div className="dd-txt inner-sides">
              $목적지명$부터의 거리
              <span className="km">1.5Km</span>
              <IconButton
                className="btn-icon-only"
                size="small"
              >
                <img src="/assets/images/icons/icon-location.svg" alt="목적지" />
              </IconButton>
            </div>
          </div>
        </li>
        
      </ul>

      {/* <div className="select-area-flex">
        <Typography variant="h3" className="bp-title title-sec">
          즐겨찾기
        </Typography>
        <FormControl>
          <FormGroup className="bp-form-group">
            <FormControlLabel
              className={`${checked ? "is-active" : ""} label-large`}
              control={
                <Checkbox onChange={(e) => setChecked(e.target.checked)} />
              }
              label={
                <Box className="inner-label">
                  <dl className="item-label">
                    <dt className="title">교통비</dt>
                    <dd>교통비 사용 | ERP001</dd>
                  </dl>
                  <div className="bookmark-area">
                    <ToggleButton
                      value="button"
                      selected2={selected2}
                      onChange={() => {
                        setSelected2(!selected2);
                      }}
                      className="btn-icon-toggle icon-bookmark"
                    >
                      <StarRateRoundedIcon fontSize="medium" />
                    </ToggleButton>
                  </div>
                </Box>
              }
            />
          </FormGroup>
        </FormControl>
      </div> */}
    </>
  );
};

export default ChooseUseList;
