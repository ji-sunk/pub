import { Card } from "@mui/material";
import { ReactNode } from "react";
interface NoticeBanProps {
  children?: ReactNode;
}

const NoticeBan = (props: NoticeBanProps) => (
  <>
    <Card>sdf</Card>
  </>
);

export default NoticeBan;
