import { TypographyOptions } from "@mui/material/styles/createTypography";

export const createTypography = (): TypographyOptions => {
  return {
    fontFamily: "Pretendard",
    h1: {
      fontSize: "3.2rem !important",
      lineHeight: 1.2,
      fontWeight: 600,
    },
    h2: {
      fontSize: "1.8rem !important",
      lineHeight: 1.2,
      fontWeight: 700,
    },
    h3: {
      fontSize: "1.6rem;",
      lineHeight: 1.2,
      fontWeight: 600,
    },
    h4: {
      fontSize: "1.4rem",
      lineHeight: 1.2,
      fontWeight: 400,
    },
    h5: {
      fontSize: "1.4rem !important",
      lineHeight: 1.2,
      fontWeight: 600,
    },
    h6: {
      fontSize: "1.3rem !important",
      lineHeight: 1.2,
      fontWeight: 600,
    },
    subtitle1: {
      fontSize: "2.4rem !important",
      lineHeight: 1.57,
      fontWeight: 400,
    },
    subtitle2: {
      fontSize: "1.4rem !important",
      lineHeight: 1.57,
      fontWeight: 400,
    },
    body1: {
      fontSize: "1.4rem",
      lineHeight: 1.5,
      fontWeight: 400,
    },
    body2: {
      fontSize: "1.3rem !important",
      lineHeight: 1.57,
      fontWeight: 400,
    },
    button: {
      fontWeight: 500,
    },
    caption: {
      fontSize: "1.2rem !important",
      lineHeight: 1.66,
    },
    overline: {
      fontSize: "1.2rem !important",
      letterSpacing: "0.5px",
      lineHeight: 2.5,
      textTransform: "uppercase",
    },
  };
};
