import { Badge, IconButton } from "@mui/material";
import { Bell01 } from "@untitled-ui/icons-react";

const AlarmButton = () => {
  //   const { lastMessage } = useAlarmSEE();
  //   const alarmPopupHook = usePopover<HTMLButtonElement>();

  //   useEffect(() => {
  //     if (lastMessage) {
  //       mutate([lastMessage, ...notifications], false);
  //     }
  //   }, [lastMessage]);

  return (
    <>
      <Badge badgeContent={5} color="error" className="new-alarm">
        <IconButton
          className="btn-icon-only"
          size="medium"
          aria-label="알림 메시지"
        >
          <Bell01 />
        </IconButton>
      </Badge>
    </>
  );
};

export default AlarmButton;
