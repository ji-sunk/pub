import { ReactNode } from "react";

import { Box, Button } from "@mui/material";

interface BtnsGroupProps {
  children?: ReactNode;
}

const navBtns = [
  { id: 1, name: "가이드", url: "/guide" },
  { id: 2, name: "작업 파일 경로", url: "/guide/path" },
];

const BtnsGroup = (props: BtnsGroupProps) => (
  <>
    <Box className="btns-group">
      <Box className="inner">
        <Button
          variant="contained"
          size="large"
          className="btn-xlarge color-neutral"
        >
          취소
        </Button>
        <Button variant="contained" size="large" className="btn-xlarge">
          확인/변경
        </Button>
      </Box>
    </Box>
  </>
);

export default BtnsGroup;
