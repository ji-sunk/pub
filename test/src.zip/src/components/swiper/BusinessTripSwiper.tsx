import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Navigation, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

// let slideInx = 0;
const BusinessTripSwiper = () => {
  SwiperCore.use([Navigation, Scrollbar]);
  return (
    <>
      <div className="bt-swiper-wrap">
        <div className="swiper-container">
          <Swiper
            // autoplay={{
            //   delay: 2500,
            //   disableOnInteraction: false, // 사용자 상호작용시 슬라이더 일시 정지 비활성
            // }}
            className=""
            loop={false} // 슬라이드 루프
            centeredSlides={true}
            // spaceBetween={12} // 슬라이스 사이 간격
            slidesPerView={1} // 보여질 슬라이스 수
            navigation={true} // prev, next button
            grabCursor={true}
          >
            {/* [S] loop */}
            <SwiperSlide className="bt-swiper-area">
              <div className="bt-swiper-box">
                <div className="section">구간1</div>
                <div className="location">양재본사 - 아산공장</div>
              </div>
            </SwiperSlide>
            {/* [E] loop */}

            <SwiperSlide className="bt-swiper-area">
              <div className="bt-swiper-box">
                <div className="section">구간2</div>
                <div className="location">양재본사 - 아산공장</div>
              </div>
            </SwiperSlide>
            <SwiperSlide className="bt-swiper-area">
              <div className="bt-swiper-box">
                <div className="section">구간3</div>
                <div className="location">양재본사 - 아산공장</div>
              </div>
            </SwiperSlide>
            <SwiperSlide className="bt-swiper-area">
              <div className="bt-swiper-box">
                <div className="section">구간4</div>
                <div className="location">양재본사 - 아산공장</div>
              </div>
            </SwiperSlide>
            <SwiperSlide className="bt-swiper-area">
              <div className="bt-swiper-box">
                <div className="section">구간5</div>
                <div className="location">양재본사 - 아산공장</div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </>
  );
};

export default BusinessTripSwiper;
