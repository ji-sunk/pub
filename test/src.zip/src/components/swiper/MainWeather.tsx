import { Box, IconButton } from "@mui/material";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { MobileDatePicker } from "@mui/x-date-pickers/MobileDatePicker";
import { useState } from "react";
import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Navigation, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

// 요일 배열 (한국어로 요일 표시)
const DAYS_OF_WEEK = [
  "일요일",
  "월요일",
  "화요일",
  "수요일",
  "목요일",
  "금요일",
  "토요일",
];

const MainWeather = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [open, setOpen] = useState(false);

  // 선택된 날짜의 요일을 계산하는 함수
  const getDayOfWeek = (date) => DAYS_OF_WEEK[date.getDay()];

  const handleDateChange = (newValue) => {
    setSelectedDate(newValue);
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  SwiperCore.use([Navigation, Scrollbar]);

  return (
    <>
      <div className="weather-wrap">
        <div className="swiper-container">
          <Swiper
            // autoplay={{
            //   delay: 2500,
            //   disableOnInteraction: false, // 사용자 상호작용시 슬라이더 일시 정지 비활성
            // }}
            className=""
            loop={false} // 슬라이드 루프
            centeredSlides={true}
            // spaceBetween={12} // 슬라이스 사이 간격
            slidesPerView={1} // 보여질 슬라이스 수
            navigation={true} // prev, next button
            grabCursor={true}
          >
            {/* [S] loop 날짜 확인 MobileDatePicker 추가 수정 241030 kjs / 지역 추가로 인한 구조 변경 241010 kjs */}
            <SwiperSlide className="weather-area">
              <Box className="weather-info">
                <Box className="weather-info-box">
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <IconButton className="left-area" onClick={handleClickOpen}>
                      <span className="date">
                        {selectedDate.toLocaleDateString("ko-KR", {
                          year: "numeric",
                          month: "2-digit",
                          day: "2-digit",
                        })}
                      </span>
                      <span className="days">{getDayOfWeek(selectedDate)}</span>
                    </IconButton>

                    <MobileDatePicker
                      open={open}
                      onClose={handleClose}
                      value={selectedDate}
                      onChange={handleDateChange}
                      slotProps={{ textField: { sx: { display: "none" } } }}
                    />
                  </LocalizationProvider>
                  <div className="right-area">
                    <span className="location bp-ellipsis">
                      서울시 영등포구 여의도동 일이삼사오육칠팔구십
                    </span>
                  </div>
                </Box>
                <Box className="current-temp inner-sides">
                  <img src="/assets/images/weather-sun.svg" alt="" />
                  <div className="weather-box">
                    <div className="status">
                      24℃ <span className="txt">맑음</span>
                    </div>
                    <div className="wind-preci inner-sides">
                      <img
                        src="/assets/images/weather-windSpeed-small.svg"
                        alt=""
                      />
                      1.5 m/s
                      <img
                        src="/assets/images/weather-humidity-small.svg"
                        alt=""
                      />
                      5%
                    </div>
                  </div>
                </Box>
              </Box>
            </SwiperSlide>
            {/* [E] loop 날짜 확인 MobileDatePicker 추가 수정 241030 kjs / 지역 추가로 인한 구조 변경 241010 kjs */}

            <SwiperSlide className="weather-area">
              <Box className="weather-info">
                <Box className="weather-info-box">
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <IconButton className="left-area" onClick={handleClickOpen}>
                      <span className="date">
                        {selectedDate.toLocaleDateString("ko-KR", {
                          year: "numeric",
                          month: "2-digit",
                          day: "2-digit",
                        })}
                      </span>
                      <span className="days">{getDayOfWeek(selectedDate)}</span>
                    </IconButton>

                    <MobileDatePicker
                      open={open}
                      onClose={handleClose}
                      value={selectedDate}
                      onChange={handleDateChange}
                      slotProps={{ textField: { sx: { display: "none" } } }}
                    />
                  </LocalizationProvider>
                  <div className="right-area">
                    <span className="location bp-ellipsis">
                      서울시 강남구 청담동
                    </span>
                  </div>
                </Box>
                <Box className="current-temp inner-sides">
                  <img src="/assets/images/weather-raining.svg" alt="" />
                  <div className="weather-box">
                    <div className="status">
                      14℃ <span className="txt">비</span>
                    </div>
                    <div className="wind-preci inner-sides">
                      <img
                        src="/assets/images/weather-windSpeed-small.svg"
                        alt=""
                      />
                      3.5 m/s
                      <img
                        src="/assets/images/weather-raining-small.svg"
                        alt=""
                      />
                      95%
                    </div>
                  </div>
                </Box>
              </Box>
            </SwiperSlide>

            <SwiperSlide className="weather-area">
              <Box className="weather-info">
                <Box className="weather-info-box">
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <IconButton className="left-area" onClick={handleClickOpen}>
                      <span className="date">
                        {selectedDate.toLocaleDateString("ko-KR", {
                          year: "numeric",
                          month: "2-digit",
                          day: "2-digit",
                        })}
                      </span>
                      <span className="days">{getDayOfWeek(selectedDate)}</span>
                    </IconButton>

                    <MobileDatePicker
                      open={open}
                      onClose={handleClose}
                      value={selectedDate}
                      onChange={handleDateChange}
                      slotProps={{ textField: { sx: { display: "none" } } }}
                    />
                  </LocalizationProvider>
                  <div className="right-area">
                    <span className="location bp-ellipsis">
                      서울시 영등포구 여의도동 일이삼사오육칠팔구십
                    </span>
                  </div>
                </Box>
                <Box className="current-temp inner-sides">
                  <img src="/assets/images/weather-sun.svg" alt="" />
                  <div className="weather-box">
                    <div className="status">
                      24℃ <span className="txt">맑음</span>
                    </div>
                    <div className="wind-preci inner-sides">
                      <img
                        src="/assets/images/weather-windSpeed-small.svg"
                        alt=""
                      />
                      1.5 m/s
                      <img
                        src="/assets/images/weather-humidity-small.svg"
                        alt=""
                      />
                      5%
                    </div>
                  </div>
                </Box>
              </Box>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </>
  );
};

export default MainWeather;
