import {
  AccessTime,
  AccountBalanceOutlined,
  BusinessCenterOutlined,
  CheckRounded,
  Dashboard,
  DynamicFeed,
  EditOutlined,
  Flight,
  HandshakeOutlined,
  MapsHomeWorkOutlined,
  SubjectRounded,
  TouchAppOutlined,
  ViewListOutlined,
  WidgetsOutlined,
} from "@mui/icons-material";
import ApprovalOutlinedIcon from "@mui/icons-material/ApprovalOutlined";
import CreditCardRoundedIcon from "@mui/icons-material/CreditCardRounded";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import PersonOutlined from "@mui/icons-material/PersonOutlined";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";
import ReceiptIcon from "@mui/icons-material/Receipt";
import SyncOutlinedIcon from "@mui/icons-material/SyncOutlined";
import { Avatar, Chip, Stack } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import {
  Calendar,
  Download02,
  Link03,
  Loading01,
  ReceiptCheck,
} from "@untitled-ui/icons-react";
import Receipt from "@untitled-ui/icons-react/build/esm/Receipt";
import styles from "./Guide.module.css";

const Badge = (props) => {
  return (
    <>
      <h3 className={styles.heading3}>5-1. [Avatar]계산서(이미지)</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="전체"
            >
              <i className="bp-icon medium icon-paper-check"></i>
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-info"
              aria-label="계산서 작성"
            >
              <i className="bp-icon medium icon-paper-write"></i>
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-warning"
              aria-label="계산서 미작성"
            >
              <i className="bp-icon medium icon-paper"></i>
            </Avatar>
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>5-2. [Avatar]기타증빙</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="전체"
            >
              <Receipt color="primary" className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-success"
              aria-label="사용내역 작성 "
            >
              <ReceiptCheck color="success" className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-warning"
              aria-label="사용내역 미작성"
            >
              <Receipt color="warning" className="bp-icon medium" />
            </Avatar>
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>5-3. [Avatar]상태</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="완료"
            >
              <CheckRounded className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-error"
              aria-label="알림"
            >
              <PriorityHighRoundedIcon className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="알림"
            >
              <PriorityHighRoundedIcon className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="알림"
            >
              <NotificationsNoneOutlinedIcon className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="상태 변경"
            >
              <SyncOutlinedIcon className="bp-icon medium" />
            </Avatar>
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>5-4. [Avatar]셋팅 메인 싱단</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Avatar
              className="bp-avatar size-medium color-twotone color-primary"
              aria-label="전체"
            >
              <Dashboard className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-success"
              aria-label="사용내역"
            >
              <CreditCardRoundedIcon className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-info"
              aria-label="계산서"
            >
              <ReceiptIcon className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-warning"
              aria-label="결재"
            >
              <ApprovalOutlinedIcon className="bp-icon medium" />
            </Avatar>
            <Avatar
              className="bp-avatar size-medium color-twotone color-warning"
              aria-label="출장문서"
            >
              <Flight className="bp-icon medium" />
            </Avatar>
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>5-5. [Avatar]셋팅 메인 카드 타입</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Avatar
              className="bp-avatar size-small color-error"
              aria-label="사용자"
            >
              <PersonOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-info"
              aria-label="직접입력"
            >
              <EditOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-info-darkest"
              aria-label="선택입력"
            >
              <TouchAppOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-primary"
              aria-label="직원"
            >
              <img
                src="/assets/images/icons/icon-setting-employee.svg"
                className="bp-icon xsmall"
              />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-secondary"
              aria-label="부서"
            >
              <MapsHomeWorkOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-primary-darkest"
              aria-label="사업부서"
            >
              <BusinessCenterOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-success"
              aria-label="거래처"
            >
              <HandshakeOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-primary"
              aria-label="지급계좌"
            >
              <img
                src="/assets/images/icons/icon-setting-paymentAccount.svg"
                className="bp-icon xsmall"
              />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-warning"
              aria-label="신청금액"
            >
              <img
                src="/assets/images/icons/icon-setting-amountApplication.svg"
                className="bp-icon xsmall"
              />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-success-darkest"
              aria-label="날짜/시간"
            >
              <AccessTime className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-success-darkest"
              aria-label="사용기간"
            >
              <Calendar className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-primary-dark"
              aria-label="프로젝트"
            >
              <DynamicFeed className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-success-dark"
              aria-label="목록"
            >
              <ViewListOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-success"
              aria-label="내용"
            >
              <SubjectRounded className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-primary-dark"
              aria-label="적요"
            >
              <CheckRounded className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-error"
              aria-label="용도"
            >
              <WidgetsOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-warning"
              aria-label="계정과목"
            >
              <AccountBalanceOutlined className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-twotone color-primary"
              aria-label="전체"
            >
              <Dashboard className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-twotone color-success"
              aria-label="사용내역"
            >
              <CreditCardRoundedIcon className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-twotone color-info"
              aria-label="계산서"
            >
              <ReceiptIcon className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-twotone color-warning"
              aria-label="결재"
            >
              <ApprovalOutlinedIcon className="bp-icon small" />
            </Avatar>
            <Avatar
              className="bp-avatar size-small color-twotone color-warning"
              aria-label="출장문서"
            >
              <Flight className="bp-icon small" />
            </Avatar>
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>5-5. [Chip]상태</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Chip
              label="대기/미작성"
              size="small"
              color="warning"
              className="bp-chip color-twotone color-warning"
            />
            <Chip
              label="진행/성공"
              size="small"
              color="success"
              className="bp-chip color-twotone color-success"
            />
            <Chip
              label="완료/작성"
              size="small"
              color="info"
              className="bp-chip color-twotone color-info"
            />
            <Chip
              label="반송/제한/실패"
              size="small"
              color="error"
              className="bp-chip color-twotone color-error"
            />
            <Chip
              label="사용"
              size="small"
              color="primary"
              className="bp-chip color-twotone color-primary"
            />
            <Chip
              label="제외/미사용"
              size="small"
              color="secondary"
              className="bp-chip color-twotone color-secondary"
            />
            <Chip
              label="2023/00/00 00:00:00 홍길동(타이틀 영역 chip)"
              size="small"
              className="bp-chip color-twotone color-action-selected"
            />
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>5-6. [Chip]셋팅 테이블 상태</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Stack direction="row" spacing={0}>
            <Chip
              label="로그인 정상"
              size="small"
              color="primary"
              className="bp-chip"
            />
            <Chip
              label="로그인 실패"
              size="small"
              color="error"
              className="bp-chip"
            />
            <Chip
              label="게시중"
              size="small"
              color="primary"
              className="bp-chip"
            />
            <Chip label="예약" size="small" color="info" className="bp-chip" />
            <Chip
              label="종료"
              size="small"
              className="bp-chip color-action-selected"
            />
            <Chip
              label="중요"
              size="small"
              color="error"
              variant="outlined"
              className="bp-chip chip-notice"
            />
            <Chip
              label="대표회사"
              size="small"
              color="primary"
              className="bp-chip"
            />
            <Chip
              label="대표회사 설정"
              size="small"
              color="primary"
              variant="outlined"
              className="bp-chip"
            />
            <Chip
              label="버튼처럼 사용할 경우"
              size="small"
              variant="outlined"
              className="bp-chip"
              icon={<Download02 fontSize="small" className="bp-icon xsmall" />}
              clickable
            />
            <Chip
              label="다운"
              size="small"
              variant="outlined"
              className="bp-chip"
              icon={<Download02 fontSize="small" className="bp-icon xsmall" />}
              clickable
            />
            <Chip
              label="연결"
              size="small"
              variant="outlined"
              className="bp-chip"
              icon={<Link03 fontSize="small" className="bp-icon xsmall" />}
              clickable
            />
            <Chip
              label="대기"
              size="small"
              variant="outlined"
              className="bp-chip"
              icon={<Loading01 fontSize="small" className="bp-icon xsmall" />}
              clickable
            />
          </Stack>
        </Grid>
      </Grid>
    </>
  );
};

export default Badge;
