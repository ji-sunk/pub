import {
  Avatar,
  Box,
  Button,
  Chip,
  ClickAwayListener,
  Grow,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  Stack,
  Typography,
} from "@mui/material";
import {
  ArrowLeft,
  ChevronDown,
  Download02,
  Edit02,
  Image03,
  Settings02,
  Share07,
  StickerCircle,
} from "@untitled-ui/icons-react";
import FilterFunnel01 from "@untitled-ui/icons-react/build/esm/FilterFunnel01";
import Receipt from "@untitled-ui/icons-react/build/esm/Receipt";
import TypeStrikethrough01 from "@untitled-ui/icons-react/build/esm/TypeStrikethrough01";
import React, { useEffect, useRef, useState } from "react";
import styles from "./Guide.module.css";

const Title = (props) => {
  /* Dropdown 버튼 */
  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  const handleWriteOpen = () => {
    setWriteOpen((prevOpen) => !prevOpen);
  };

  const handleWriteClose = (event: Event | React.SyntheticEvent) => {
    if (
      writeAnchorRef.current &&
      writeAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setWriteOpen(false);
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === "Tab") {
      event.preventDefault();
      setWriteOpen(false);
    } else if (event.key === "Escape") {
      setWriteOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);

  return (
    <>
      <h3 className={styles.heading3}>1-1. [공통]기본 Typography</h3>
      {/* [S]타이틀 그룹 */}
      <Stack spacing={0} className="bp-group-title">
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-main"
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box className="left">
            <Typography variant="h1" className="bp-title title-top logo">
              <img src="/assets/images/logo_bizplay_big2.png" alt="bizplay" />
            </Typography>
          </Box>
          <Box className="right">
            <Button
              size="small"
              className="btn-text-primary btn-go-back"
              startIcon={
                <ArrowLeft fontSize="small" className="bp-icon xsmall" />
              }
            >
              뒤로가기
            </Button>
          </Box>
        </Stack>
        <Stack spacing={0} className="bp-group-title-row" direction="row">
          <Box className="left">
            <Typography variant="h2" className="bp-title title-sub title-login">
              h2 타이틀
            </Typography>
            <Typography variant="h2" className="bp-title title-sub title-login">
              h2 타이틀
            </Typography>
          </Box>
          <Box className="right"></Box>
        </Stack>
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-description"
          direction="row"
        >
          <Box className="left">
            <Typography variant="body1" className="bp-description">
              관리자가 생성한 계정은 최초 로그인 시 이용약관 동의가 필요합니다.
              서비스 이용을 위해 아래 이용약관에 동의해주세요.
            </Typography>
          </Box>
          <Box className="right"></Box>
        </Stack>
      </Stack>
      {/* [E]타이틀 그룹 */}

      <h3 className={styles.heading3}>6-2. [공통]기본 레이아웃 타이틀</h3>
      {/* [S]타이틀 그룹 */}
      <Stack spacing={0} className="bp-group-title title-top">
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-go-back"
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box className="left">
            <Button
              size="small"
              className="btn-text-primary btn-go-back"
              startIcon={
                <ArrowLeft fontSize="small" className="bp-icon xsmall" />
              }
            >
              뒤로가기
            </Button>
          </Box>
          <Box className="right"></Box>
        </Stack>
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-main"
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box className="left">
            <Typography variant="h1" className="bp-title title-top">
              h1 타이틀
            </Typography>
            <Typography variant="body2" className="bp-etc-info">
              2023년 11월 1일 수요일
            </Typography>
          </Box>
          <Box className="right">
            <Button
              size="small"
              className="btn-text-primary"
              startIcon={
                <FilterFunnel01 fontSize="small" className="bp-icon xsmall" />
              }
            >
              기본 필터
            </Button>
          </Box>
        </Stack>
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-main"
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box className="left">
            <dl className="item-corporation">
              <dt>
                <Avatar className="bp-state state-receipt color-error">
                  {/* 미작성:노란색(color-warning),작성:녹색(color-success),마감(제한):빨간색(color-error) */}
                  <TypeStrikethrough01 />
                  <Receipt />
                </Avatar>
              </dt>
              <dd>
                <Typography variant="h1" className="bp-title title-top">
                  스타벅스 영등포점
                </Typography>
                <dl className="item-info-chip">
                  <dt>추가정보 :</dt>
                  <dd>
                    <Chip
                      label="최종 변경: yyyy/mm/dd hh:mm 김이름(userid)"
                      size="small"
                      className="bp-chip color-twotone color-action-selected"
                    />
                  </dd>
                </dl>
              </dd>
            </dl>
          </Box>
          <Box className="right">
            <Button
              size="small"
              className="btn-text-primary"
              startIcon={
                <Image03 fontSize="small" className="bp-icon xsmall" />
              }
            >
              이미지 첨부
            </Button>
            <Button
              size="small"
              className="btn-text-primary"
              startIcon={
                <StickerCircle fontSize="small" className="bp-icon xsmall" />
              }
            >
              메모
            </Button>
            <Button
              size="small"
              className="btn-text-primary"
              startIcon={
                <Share07 fontSize="small" className="bp-icon xsmall" />
              }
            >
              회람
            </Button>
            <Box className="btn-dropdown">
              <Button
                variant="contained"
                size="medium"
                id="write-button"
                onClick={handleWriteOpen}
                ref={writeAnchorRef}
                aria-controls={writeOpen ? "write-menu" : undefined}
                aria-expanded={writeOpen ? "true" : undefined}
                aria-haspopup="true"
                startIcon={
                  <Edit02 fontSize="small" className="bp-icon xsmall" />
                }
                endIcon={
                  <ChevronDown fontSize="small" className="bp-icon xsmall" />
                }
              >
                작성하기
              </Button>
              <Popper
                open={writeOpen}
                anchorEl={writeAnchorRef.current}
                role={undefined}
                placement="bottom-start"
                transition
                disablePortal
                className="popper-dropdown fullWidth"
              >
                {({ TransitionProps, placement }) => (
                  <Grow
                    {...TransitionProps}
                    style={{
                      transformOrigin:
                        placement === "bottom-start"
                          ? "left top"
                          : "left bottom",
                    }}
                  >
                    <Paper>
                      <ClickAwayListener onClickAway={handleWriteClose}>
                        <MenuList
                          autoFocusItem={writeOpen}
                          id="write-menu"
                          aria-labelledby="write-button"
                          onKeyDown={handleListKeyDown}
                        >
                          <MenuItem onClick={handleWriteClose}>
                            작성하기
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            분할하기
                          </MenuItem>
                          <MenuItem onClick={handleWriteClose}>
                            세액 수정
                          </MenuItem>
                        </MenuList>
                      </ClickAwayListener>
                    </Paper>
                  </Grow>
                )}
              </Popper>
            </Box>
          </Box>
        </Stack>
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-btnsGroup"
          direction="row"
        >
          <Box className="left">
            <Button
              size="small"
              className="btn-text-primary"
              startIcon={
                <Download02 fontSize="small" className="bp-icon xsmall" />
              }
            >
              저장/다운로드/양식 다운로드/양식 다운로드(신규)/양식 다운로드(기존
              자료 포함)
            </Button>
            <Button
              size="small"
              className="btn-text-primary"
              startIcon={
                <Settings02 fontSize="small" className="bp-icon xsmall" />
              }
            >
              상세 필터
            </Button>
          </Box>
          <Box className="right"></Box>
        </Stack>
        <Stack spacing={0} className="bp-group-title-row" direction="row">
          <Box className="left">
            <Typography variant="h2" className="bp-title title-sub">
              h2 타이틀
            </Typography>
          </Box>
          <Box className="right"></Box>
        </Stack>
        <Stack
          spacing={0}
          className="bp-group-title-row bp-group-title-description"
          direction="row"
        >
          <Box className="left">
            <Chip
              label="최종 변경: yyyy/mm/dd hh:mm 김이름(userid)"
              size="small"
              className="bp-chip color-twotone color-action-selected"
            />
            <Typography variant="body1" className="bp-description">
              최종 변경: yyyy/mm/dd hh:mm 김이름(userid)
            </Typography>
          </Box>
          <Box className="right"></Box>
        </Stack>
      </Stack>
      {/* [E]타이틀 그룹 */}
    </>
  );
};

export default Title;
