import { Box, Stack, Typography } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import ChipsGroup from "../common/ChipsGroup";
import styles from "./Guide.module.css";

const Typo = (props) => {
  return (
    <>
      <h3 className={styles.heading3}>1-1. [공통]기본 Typography</h3>
      <Grid container spacing={2}>
        <Grid xs={12}>
          <Typography variant="h1" gutterBottom>
            h1. Heading
          </Typography>
          <Typography variant="h2" gutterBottom>
            h2. Heading
          </Typography>
          <Typography variant="h3" gutterBottom>
            h3. Heading
          </Typography>
          <Typography variant="h4" gutterBottom>
            h4. Heading
          </Typography>
          <Typography variant="h5" gutterBottom>
            h5. Heading
          </Typography>
          <Typography variant="h6" gutterBottom>
            h6. Heading
          </Typography>
          <Typography variant="subtitle1" gutterBottom>
            subtitle1. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Quos blanditiis tenetur
          </Typography>
          <Typography variant="subtitle2" gutterBottom>
            subtitle2. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Quos blanditiis tenetur
          </Typography>
          <Typography variant="body1" gutterBottom>
            body1. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Quos blanditiis tenetur unde suscipit, quam beatae rerum inventore
            consectetur, neque doloribus, cupiditate numquam dignissimos laborum
            fugiat deleniti? Eum quasi quidem quibusdam.
          </Typography>
          <Typography variant="body2" gutterBottom>
            body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Quos blanditiis tenetur unde suscipit, quam beatae rerum inventore
            consectetur, neque doloribus, cupiditate numquam dignissimos laborum
            fugiat deleniti? Eum quasi quidem quibusdam.
          </Typography>
          <Typography variant="button" display="block" gutterBottom>
            button text
          </Typography>
          <Typography variant="caption" display="block" gutterBottom>
            caption text
          </Typography>
          <Typography variant="overline" display="block" gutterBottom>
            overline text
          </Typography>
          <Typography variant="body2" className="text-primary">
            primary 텍스트 색상:className="text-primary"
          </Typography>
          <Typography variant="body2" className="text-error">
            error 텍스트 색상:className="text-error"
          </Typography>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>1-2. [공통]기본 컬러 패턴</h3>
      <Grid container spacing={2} className="color-palette-group">
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-primary-lightest">
              <span>primary.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-primary-light">
              <span>primary.light</span>
            </Stack>
            <Stack className="color-palette color-palette-primary">
              <Box>primary</Box>
              <Box sx={{ fontSize: "10px" }}>#002C5F</Box>
            </Stack>
            <Stack className="color-palette color-palette-primary-main">
              <Box>primary.main</Box>
              <Box sx={{ fontSize: "10px" }}>#002C5F</Box>
            </Stack>
            <Stack className="color-palette color-palette-primary-dark">
              <span>primary.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-primary-darkest">
              <span>primary.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-secondary-lightest">
              <span>secondary.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-secondary-light">
              <span>secondary.light</span>
            </Stack>
            <Stack className="color-palette color-palette-secondary">
              <Box>secondary</Box>
              <Box sx={{ fontSize: "10px" }}>#00AAD2</Box>
            </Stack>
            <Stack className="color-palette color-palette-secondary-main">
              <Box>secondary.main</Box>
              <Box sx={{ fontSize: "10px" }}>#00AAD2</Box>
            </Stack>
            <Stack className="color-palette color-palette-secondary-dark">
              <span>secondary.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-secondary-darkest">
              <span>secondary.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-error-lightest">
              <span>error.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-error-light">
              <span>error.light</span>
            </Stack>
            <Stack className="color-palette color-palette-error">
              <span>error</span>
            </Stack>
            <Stack className="color-palette color-palette-error-main">
              <span>error.main</span>
            </Stack>
            <Stack className="color-palette color-palette-error-dark">
              <span>error.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-error-darkest">
              <span>error.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-warning-lightest">
              <span>warning.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-warning-light">
              <span>warning.light</span>
            </Stack>
            <Stack className="color-palette color-palette-warning">
              <span>warning</span>
            </Stack>
            <Stack className="color-palette color-palette-warning-main">
              <span>warning.main</span>
            </Stack>
            <Stack className="color-palette color-palette-warning-dark">
              <span>warning.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-warning-darkest">
              <span>warning.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-info-lightest">
              <span>info.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-info-light">
              <span>info.light</span>
            </Stack>
            <Stack className="color-palette color-palette-info">
              <span>info</span>
            </Stack>
            <Stack className="color-palette color-palette-info-main">
              <span>info.main</span>
            </Stack>
            <Stack className="color-palette color-palette-info-dark">
              <span>info.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-info-darkest">
              <span>info.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-purple-lightest">
              <span>purple.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-purple-light">
              <span>purple.light</span>
            </Stack>
            <Stack className="color-palette color-palette-purple">
              <span>purple</span>
            </Stack>
            <Stack className="color-palette color-palette-purple-main">
              <span>purple.main</span>
            </Stack>
            <Stack className="color-palette color-palette-purple-dark">
              <span>purple.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-purple-darkest">
              <span>purple.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-indigo-lightest">
              <span>indigo.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-indigo-light">
              <span>indigo.light</span>
            </Stack>
            <Stack className="color-palette color-palette-indigo">
              <span>indigo</span>
            </Stack>
            <Stack className="color-palette color-palette-indigo-main">
              <span>indigo.main</span>
            </Stack>
            <Stack className="color-palette color-palette-indigo-dark">
              <span>indigo.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-indigo-darkest">
              <span>indigo.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-green-lightest">
              <span>green.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-green-light">
              <span>green.light</span>
            </Stack>
            <Stack className="color-palette color-palette-green">
              <span>green</span>
            </Stack>
            <Stack className="color-palette color-palette-green-main">
              <span>green.main</span>
            </Stack>
            <Stack className="color-palette color-palette-green-dark">
              <span>green.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-green-darkest">
              <span>green.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-blue-lightest">
              <span>blue.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-blue-light">
              <span>blue.light</span>
            </Stack>
            <Stack className="color-palette color-palette-blue">
              <span>blue</span>
            </Stack>
            <Stack className="color-palette color-palette-blue-main">
              <span>blue.main</span>
            </Stack>
            <Stack className="color-palette color-palette-blue-dark">
              <span>blue.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-blue-darkest">
              <span>blue.darkest</span>
            </Stack>
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-success-lightest">
              <span>success.lightest</span>
            </Stack>
            <Stack className="color-palette color-palette-success-light">
              <span>success.light</span>
            </Stack>
            <Stack className="color-palette color-palette-success">
              <span>success</span>
            </Stack>
            <Stack className="color-palette color-palette-success-main">
              <span>success.main</span>
            </Stack>
            <Stack className="color-palette color-palette-success-dark">
              <span>success.dark</span>
            </Stack>
            <Stack className="color-palette color-palette-success-darkest">
              <span>success.darkest</span>
            </Stack>
          </Stack>
        </Grid>

        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-neutral-50">
              <span>neutral.50</span>
            </Stack>
            <Stack className="color-palette color-palette-neutral-100">
              <span>neutral.100</span>
            </Stack>
            <Stack className="color-palette color-palette-neutral-200">
              <span>neutral.200</span>
            </Stack>
            <Stack className="color-palette color-palette-neutral-300">
              <span>neutral.300</span>
            </Stack>
            <Stack className="color-palette color-palette-neutral-400">
              <span>neutral.400</span>
            </Stack>
            {/* <Stack className="color-palette color-palette-neutral-500">
              <span>neutral.500</span>
            </Stack> */}
            <Stack className="color-palette color-palette-neutral-600">
              <span>neutral.600</span>
            </Stack>
            {/* <Stack className="color-palette color-palette-neutral-700">
              <span>neutral.700</span>
            </Stack>
            <Stack className="color-palette color-palette-neutral-800">
              <span>neutral.800</span>
            </Stack>
            <Stack className="color-palette color-palette-neutral-900">
              <span>neutral.900</span>
            </Stack> */}
          </Stack>
        </Grid>
        <Grid xs={12}>
          <Stack direction="row" spacing={2}>
            <Stack className="color-palette color-palette-green">
              <Box>green</Box>
              <Box sx={{ fontSize: "10px" }}>#04B249</Box>
            </Stack>
            <Stack className="color-palette color-palette-yellow">
              <Box>yellow</Box>
              <Box sx={{ fontSize: "10px" }}>#913DE5</Box>
            </Stack>
            <Stack className="color-palette color-palette-orange">
              <Box>orange</Box>
              <Box sx={{ fontSize: "10px" }}>#FD6A00</Box>
            </Stack>
            <Stack className="color-palette color-palette-red">
              <Box>red</Box>
              <Box sx={{ fontSize: "10px" }}>#F13E3E</Box>
            </Stack>
            <Stack className="color-palette color-palette-blue">
              <Box>blue</Box>
              <Box sx={{ fontSize: "10px" }}>#3478FE</Box>
            </Stack>
            <Stack className="color-palette color-palette-violet">
              <Box>violet</Box>
              <Box sx={{ fontSize: "10px" }}>#913DE5</Box>
            </Stack>
          </Stack>
        </Grid>
      </Grid>
      <h3 className={styles.heading3}>1-3. [공통]chip 패턴</h3>
      <Grid
        container
        spacing={2}
        sx={{ backgroundColor: "#fff", borderRadius: "8px" }}
      >
        <Grid xs={12}>
          <ChipsGroup />
        </Grid>
      </Grid>
    </>
  );
};

export default Typo;
