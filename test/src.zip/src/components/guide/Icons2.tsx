import { LinkOff } from "@mui/icons-material";
import AltRouteRoundedIcon from "@mui/icons-material/AltRouteRounded";
import ApprovalRoundedIcon from "@mui/icons-material/ApprovalRounded";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";
import CampaignIcon from "@mui/icons-material/Campaign";
import CheckRounded from "@mui/icons-material/CheckRounded";
import ContactEmergencyOutlinedIcon from "@mui/icons-material/ContactEmergencyOutlined";
import CreditCardRoundedIcon from "@mui/icons-material/CreditCardRounded";
import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";
import EqualizerRoundedIcon from "@mui/icons-material/EqualizerRounded";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import LeaderboardOutlinedIcon from "@mui/icons-material/LeaderboardOutlined";
import ListAltRoundedIcon from "@mui/icons-material/ListAltRounded";
import PauseCircleOutlinedIcon from "@mui/icons-material/PauseCircleOutlined";
import PauseRoundedIcon from "@mui/icons-material/PauseRounded";
import PersonIcon from "@mui/icons-material/Person";
import PieChartOutlineIcon from "@mui/icons-material/PieChartOutline";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";
import ReceiptIcon from "@mui/icons-material/Receipt";
import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";
import ReorderRoundedIcon from "@mui/icons-material/ReorderRounded";
import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";
import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";
import SyncRoundedIcon from "@mui/icons-material/SyncRounded";
import WifiProtectedSetupOutlinedIcon from "@mui/icons-material/WifiProtectedSetupOutlined";
import { List, ListItem } from "@mui/material";
import {
  ArrowLeft,
  ArrowRight,
  Bank,
  BarChartSquare02,
  Bell01,
  Bookmark,
  Briefcase02,
  Building05,
  Bus,
  Car01,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ClipboardCheck,
  Clock,
  ClockSnooze,
  Columns02,
  Copy06,
  CpuChip01,
  CreditCard01,
  CreditCardEdit,
  CreditCardRefresh,
  CreditCardSearch,
  Dotpoints01,
  DotsHorizontal,
  DotsVertical,
  Download01,
  Download02,
  Edit02,
  Edit03,
  Edit05,
  Expand01,
  FaceId,
  File02,
  File05,
  FileAttachment04,
  FileCheck01,
  FileCheck02,
  FilePlus02,
  FileSearch02,
  FileX03,
  FolderPlus,
  Globe02,
  Heart,
  Home03,
  Box as IconBox,
  Image03,
  InfoCircle,
  Link03,
  Loading01,
  LogOut01,
  Mark,
  MarkerPin01,
  MessageAlertCircle,
  MessageCheckSquare,
  MessageDotsCircle,
  Minus,
  MinusCircle,
  Paperclip,
  ParagraphSpacing,
  Pencil02,
  PencilLine,
  Percent03,
  Plane,
  Printer,
  ReceiptCheck,
  RefreshCcw01,
  RefreshCcw04,
  ReverseLeft,
  SearchSm,
  Settings02,
  Settings04,
  Share07,
  SlashOctagon,
  Star01,
  StickerCircle,
  Target03,
  Ticket02,
  Train,
  Trash02,
  Upload01,
  UserCheck01,
  UserCircle,
  UserEdit,
  UserPlus01,
  Users03,
  XCircle,
  XSquare,
} from "@untitled-ui/icons-react";
import FilterFunnel01 from "@untitled-ui/icons-react/build/esm/FilterFunnel01";
import Plus from "@untitled-ui/icons-react/build/esm/Plus";
import Receipt from "@untitled-ui/icons-react/build/esm/Receipt";
import { ReactNode } from "react";
import styles from "./Guide.module.css";

interface IconsProps {
  children?: ReactNode;
  name?: string;
  txt?: string;
  impoTxt?: string;
}

const iconList = [
  {
    id: 1,
    name: "SearchSm",
    txt: "검색",
    impoTxt: 'import { SearchSm } from "@untitled-ui/icons-react";',
  },
  {
    id: 2,
    name: "ArrowLeft",
    txt: "뒤로가기",
    impoTxt: 'import { ArrowLeft } from "@untitled-ui/icons-react";',
  },
  {
    id: 3,
    name: "ArrowRight",
    txt: "바로가기",
    impoTxt:
      'import ArrowRight from "@mui/icons-material/ArrowForwardOutlined";',
  },
  {
    id: 4,
    name: "ChevronLeft",
    txt: "왼쪽으로",
    impoTxt: 'import { ChevronLeft } from "@untitled-ui/icons-react";',
  },
  {
    id: 5,
    name: "ChevronRight",
    txt: "바로가기 아이콘 버튼",
    impoTxt: 'import { ChevronRight } from "@untitled-ui/icons-react";',
  },
  {
    id: 6,
    name: "DotsHorizontal",
    txt: "대기/더보기 아이콘 버튼",
    impoTxt: 'import { DotsHorizontal } from "@untitled-ui/icons-react";',
  },
  {
    id: 7,
    name: "PriorityHighRoundedIcon",
    txt: "반송",
    impoTxt:
      'import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";',
  },
  {
    id: 8,
    name: "SyncRoundedIcon",
    txt: "진행",
    impoTxt: 'import SyncRoundedIcon from "@mui/icons-material/SyncRounded";',
  },
  {
    id: 9,
    name: "CheckRounded",
    txt: "완료",
    impoTxt: 'import CheckRounded from "@mui/icons-material/CheckRounded";',
  },
  {
    id: 10,
    name: "PauseRoundedIcon",
    txt: "보류",
    impoTxt: 'import PauseRoundedIcon from "@mui/icons-material/PauseRounded";',
  },

  {
    id: 12,
    name: "PauseCircleOutlinedIcon",
    txt: "일시 정지 아이콘 버튼",
    impoTxt:
      'import PauseCircleOutlinedIcon from "@mui/icons-material/PauseCircleOutlined";',
  },
  {
    id: 13,
    name: "PersonIcon",
    txt: "사람",
    impoTxt: 'import PersonIcon from "@mui/icons-material/Person";',
  },
  {
    id: 16,
    name: "DotsVertical",
    txt: "더보기/레이어 열기",
    impoTxt: 'import { DotsVertical } from "@untitled-ui/icons-react";',
  },
  {
    id: 17,
    name: "Download02",
    txt: "저장/다운로드/양식 다운로드",
    impoTxt: 'import { Download02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 18,
    name: "Bookmark",
    txt: "보관",
    impoTxt: 'import { Bookmark } from "@untitled-ui/icons-react";',
  },
  {
    id: 19,
    name: "Printer",
    txt: "인쇄",
    impoTxt: 'import { Printer } from "@untitled-ui/icons-react";',
  },
  {
    id: 20,
    name: "Edit02",
    txt: "결의서 작성/수정/양식수정",
    impoTxt: 'import { Edit02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 21,
    name: "FilterFunnel01",
    txt: "필터",
    impoTxt:
      'import FilterFunnel01 from "@untitled-ui/icons-react/build/esm/FilterFunnel01";',
  },
  {
    id: 22,
    name: "Settings02",
    txt: "상세 필터",
    impoTxt: 'import { Settings02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 23,
    name: "StickerCircle",
    txt: "메모",
    impoTxt: 'import { StickerCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 24,
    name: "Settings04",
    txt: "보기설정",
    impoTxt: 'import { Settings04 } from "@untitled-ui/icons-react";',
  },
  {
    id: 25,
    name: "MinusCircle",
    txt: "제외/해제",
    impoTxt: 'import { MinusCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 26,
    name: "Upload01",
    txt: "업로드",
    impoTxt: 'import { Upload01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 27,
    name: "Image03",
    txt: "이미지 첨부",
    impoTxt: 'import { Image03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 28,
    name: "Share07",
    txt: "회람",
    impoTxt: 'import { Share07 } from "@untitled-ui/icons-react";',
  },
  {
    id: 29,
    name: "UserPlus01",
    txt: "임시담당자 지정",
    impoTxt: 'import { UserPlus01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 30,
    name: "Building05",
    txt: "회사정보",
    impoTxt: 'import { Building05 } from "@untitled-ui/icons-react";',
  },
  {
    id: 31,
    name: "Users03",
    txt: "직원조회",
    impoTxt: 'import { Users03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 32,
    name: "Plus",
    txt: "추가/행추가",
    impoTxt: 'import Plus from "@untitled-ui/icons-react/build/esm/Plus";',
  },
  {
    id: 33,
    name: "Minus",
    txt: "삭제/행제거",
    impoTxt: 'import { Minus } from "@untitled-ui/icons-react";',
  },
  {
    id: 34,
    name: "Trash02",
    txt: "삭제",
    impoTxt: 'import { Trash02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 35,
    name: "Clock",
    txt: "마감/해제",
    impoTxt: 'import { Clock } from "@untitled-ui/icons-react";',
  },
  {
    id: 36,
    name: "ApprovalRoundedIcon",
    txt: "결재/접수결재",
    impoTxt:
      'import ApprovalRoundedIcon from "@mui/icons-material/ApprovalRounded";',
  },
  {
    id: 37,
    name: "ParagraphSpacing",
    txt: "증빙내역 펼치기",
    impoTxt: 'import { ParagraphSpacing } from "@untitled-ui/icons-react";',
  },
  {
    id: 38,
    name: "Expand01",
    txt: "증빙내역 펼치기",
    impoTxt: 'import { Expand01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 39,
    name: "XCircle",
    txt: "상신취소/최종결재취소",
    impoTxt: 'import { XCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 40,
    name: "PencilLine",
    txt: "재기안",
    impoTxt: 'import { PencilLine } from "@untitled-ui/icons-react";',
  },
  {
    id: 41,
    name: "XSquare",
    txt: "최종결재취소",
    impoTxt: 'import { XSquare } from "@untitled-ui/icons-react";',
  },
  {
    id: 42,
    name: "FileSearch02",
    txt: "거래처 불러오기",
    impoTxt: 'import { FileSearch02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 43,
    name: "RefreshCcw01",
    txt: "초기화/최신정보 불러오기/새로고침",
    impoTxt: 'import { RefreshCcw01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 44,
    name: "Download01",
    txt: "일괄입력",
    impoTxt: 'import { Download01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 45,
    name: "AltRouteRoundedIcon",
    txt: "분할",
    impoTxt:
      'import AltRouteRoundedIcon from "@mui/icons-material/AltRouteRounded";',
  },
  {
    id: 46,
    name: "WifiProtectedSetupOutlinedIcon",
    txt: "국세청 가져오기",
    impoTxt:
      'import WifiProtectedSetupOutlinedIcon from "@mui/icons-material/WifiProtectedSetupOutlined";',
  },
  {
    id: 47,
    name: "FolderPlus",
    txt: "카드그룹 생성",
    impoTxt: 'import { FolderPlus } from "@untitled-ui/icons-react";',
  },
  {
    id: 48,
    name: "MessageAlertCircle",
    txt: "결재의견",
    impoTxt: 'import { MessageAlertCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 49,
    name: "ClipboardCheck",
    txt: "결재정보",
    impoTxt: 'import { ClipboardCheck } from "@untitled-ui/icons-react";',
  },
  {
    id: 50,
    name: "RefreshCcw04",
    txt: "결재선 변경",
    impoTxt: 'import { RefreshCcw04 } from "@untitled-ui/icons-react";',
  },
  {
    id: 51,
    name: "FileCheck01",
    txt: "양식선택",
    impoTxt: 'import { FileCheck01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 52,
    name: "Columns02",
    txt: "결재란 설정",
    impoTxt: 'import { Columns02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 53,
    name: "UserCheck01",
    txt: "양식별 결재선 설정",
    impoTxt: 'import { UserCheck01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 54,
    name: "Copy06",
    txt: "양식복사",
    impoTxt: 'import { Copy06 } from "@untitled-ui/icons-react";',
  },
  {
    id: 55,
    name: "ReverseLeft",
    txt: "반려",
    impoTxt: 'import { ReverseLeft } from "@untitled-ui/icons-react";',
  },
  {
    id: 56,
    name: "Paperclip",
    txt: "파일",
    impoTxt: 'import { Paperclip } from "@untitled-ui/icons-react";',
  },
  {
    id: 57,
    name: "ChevronDown",
    txt: "열기/아래로",
    impoTxt: 'import { ChevronDown } from "@untitled-ui/icons-react";',
  },
  {
    id: 58,
    name: "ChevronUp",
    txt: "위로",
    impoTxt: 'import { ChevronUp } from "@untitled-ui/icons-react";',
  },
  {
    id: 59,
    name: "ArrowDropDownIcon",
    txt: "열기",
    impoTxt:
      'import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";',
  },
  {
    id: 60,
    name: "Link03",
    txt: "연결",
    impoTxt: 'import { Link03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 61,
    name: "Bell01",
    txt: "알림",
    impoTxt: 'import { Bell01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 62,
    name: "Edit05",
    txt: "편집/글쓰기/수정",
    impoTxt: 'import { Edit05 } from "@untitled-ui/icons-react";',
  },
  {
    id: 63,
    name: "FileAttachment04",
    txt: "원안문서",
    impoTxt: 'import { FileAttachment04 } from "@untitled-ui/icons-react";',
  },
  {
    id: 64,
    name: "InfoCircle",
    txt: "설명",
    impoTxt: 'import { InfoCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 65,
    name: "ListAltRoundedIcon",
    txt: "보관함 선택",
    impoTxt:
      'import ListAltRoundedIcon from "@mui/icons-material/ListAltRounded";',
  },
  {
    id: 66,
    name: "LeaderboardOutlinedIcon",
    txt: "Bar 차트",
    impoTxt:
      'import LeaderboardOutlinedIcon from "@mui/icons-material/LeaderboardOutlined";',
  },
  {
    id: 67,
    name: "PieChartOutlineIcon",
    txt: "Pie 차트",
    impoTxt:
      'import PieChartOutlineIcon from "@mui/icons-material/PieChartOutline";',
  },
  {
    id: 68,
    name: "LinkOff",
    txt: "해지",
    impoTxt: 'import { LinkOff } from "@mui/icons-material";',
  },
  {
    id: 69,
    name: "Loading01",
    txt: "대기",
    impoTxt: 'import { Loading01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 70,
    name: "Globe02",
    txt: "언어설정",
    impoTxt: 'import { Globe02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 71,
    name: "FaceId",
    txt: "페이스아이디",
    impoTxt: 'import { FaceId } from "@untitled-ui/icons-react";',
  },
  {
    id: 72,
    name: "CpuChip01",
    txt: "AI보고서",
    impoTxt: 'import { CpuChip01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 72,
    name: "Pencil02",
    txt: "개인정보수정",
    impoTxt: 'import { Pencil02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 73,
    name: "SlashOctagon",
    txt: "정산정보 에러",
    impoTxt: 'import { SlashOctagon } from "@untitled-ui/icons-react";',
  },

  {
    id: 74,
    name: "File05",
    txt: "전체메뉴_File05",
    impoTxt: 'import { File05 } from "@untitled-ui/icons-react";',
  },
  {
    id: 75,
    name: "CreditCardEdit",
    txt: "전체메뉴_예약/결제 내역",
    impoTxt: 'import { CreditCardEdit } from "@untitled-ui/icons-react";',
  },
  {
    id: 76,
    name: "UserCircle",
    txt: "전체메뉴_마이페이지",
    impoTxt: 'import { UserCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 77,
    name: "File02",
    txt: "전체메뉴_계획서 목록",
    impoTxt: 'import { File02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 78,
    name: "UserEdit",
    txt: "전체메뉴_대리작성",
    impoTxt: 'import { UserEdit } from "@untitled-ui/icons-react";',
  },
  {
    id: 79,
    name: "Train",
    txt: "전체메뉴_열차",
    impoTxt: 'import { Train } from "@untitled-ui/icons-react";',
  },
  {
    id: 80,
    name: "Bus",
    txt: "전체메뉴_고속버스",
    impoTxt: 'import { Bus } from "@untitled-ui/icons-react";',
  },
  {
    id: 81,
    name: "Plane",
    txt: "전체메뉴_항공",
    impoTxt: 'import { Plane } from "@untitled-ui/icons-react";',
  },
  {
    id: 82,
    name: "Percent03",
    txt: "전체메뉴_정산서목록",
    impoTxt: 'import { Percent03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 83,
    name: "Edit03",
    txt: "전체메뉴_정산서작성",
    impoTxt: 'import { Edit03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 84,
    name: "Briefcase02",
    txt: "전체메뉴_메뉴기본아이콘",
    impoTxt: 'import { Briefcase02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 85,
    name: "Dotpoints01",
    txt: "전체메뉴_부서출장계획서목록",
    impoTxt: 'import { Dotpoints01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 86,
    name: "IconBox",
    txt: "마이페이지_내결제함",
    impoTxt: 'import { IconBox } from "@untitled-ui/icons-react";',
  },
  {
    id: 86,
    name: "FilePlus02",
    txt: "마이페이지_출장계획서목록",
    impoTxt: 'import { FilePlus02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 87,
    name: "FileCheck02",
    txt: "마이페이지_출장정산서목록",
    impoTxt: 'import { FileCheck02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 88,
    name: "CreditCardSearch",
    txt: "마이페이지_예약내역",
    impoTxt: 'import { CreditCardSearch } from "@untitled-ui/icons-react";',
  },
  {
    id: 89,
    name: "FileX03",
    txt: "마이페이지_취소내역",
    impoTxt: 'import { FileX03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 90,
    name: "ClockSnooze",
    txt: "마이페이지_임시보관함",
    impoTxt: 'import { ClockSnooze } from "@untitled-ui/icons-react";',
  },
  {
    id: 91,
    name: "CreditCardRefresh",
    txt: "마이페이지_출장비회수내역",
    impoTxt: 'import { CreditCardRefresh } from "@untitled-ui/icons-react";',
  },
  {
    id: 92,
    name: "Bank",
    txt: "마이페이지_내계좌관리",
    impoTxt: 'import { Bank } from "@untitled-ui/icons-react";',
  },
  {
    id: 93,
    name: "Car01",
    txt: "마이페이지_내차관리",
    impoTxt: 'import { Car01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 94,
    name: "Ticket02",
    txt: "마이페이지_하이패스관리",
    impoTxt: 'import { Ticket02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 95,
    name: "BarChartSquare02",
    txt: "마이페이지_마이데이터",
    impoTxt: 'import { BarChartSquare02 } from "@untitled-ui/icons-react";',
  },
  {
    id: 96,
    name: "MessageDotsCircle",
    txt: "마이페이지_1:1문의하기",
    impoTxt: 'import { MessageDotsCircle } from "@untitled-ui/icons-react";',
  },
  {
    id: 97,
    name: "Heart",
    txt: "마이페이지_나의관심상품",
    impoTxt: 'import { Heart } from "@untitled-ui/icons-react";',
  },
  {
    id: 98,
    name: "Star01",
    txt: "마이페이지_나의평점리뷰",
    impoTxt: 'import { Star01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 99,
    name: "MarkerPin01",
    txt: "마이페이지_즐겨찾기",
    impoTxt: 'import { MarkerPin01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 100,
    name: "MessageCheckSquare",
    txt: "마이페이지_출장메모",
    impoTxt: 'import { MessageCheckSquare } from "@untitled-ui/icons-react";',
  },
  {
    id: 101,
    name: "LogOut01",
    txt: "마이페이지_로그아웃",
    impoTxt: 'import { LogOut01 } from "@untitled-ui/icons-react";',
  },
  {
    id: 102,
    name: "Mark",
    txt: "교통수단추천",
    impoTxt: 'import { Mark } from "@untitled-ui/icons-react";',
  },
  {
    id: 103,
    name: "Home03",
    txt: "홈",
    impoTxt: 'import { Home03 } from "@untitled-ui/icons-react";',
  },
  {
    id: 104,
    name: "Target03",
    txt: "GPS",
    impoTxt: 'import { Target03 } from "@untitled-ui/icons-react";',
  },
];

const iconLnbList = [
  {
    id: 1,
    name: "SpaceDashboardIcon",
    txt: "HOME",
    impoTxt:
      'import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";',
  },
  {
    id: 2,
    name: "ReceiptIcon",
    txt: "경비",
    impoTxt: 'import ReceiptIcon from "@mui/icons-material/Receipt";',
  },
  {
    id: 3,
    name: "ApprovalRoundedIcon",
    txt: "결재",
    impoTxt:
      'import ApprovalRoundedIcon from "@mui/icons-material/ApprovalRounded";',
  },
  {
    id: 4,
    name: "EqualizerRoundedIcon",
    txt: "리포트(기획 요청 변경:20240308)",
    impoTxt:
      'import EqualizerRoundedIcon from "@mui/icons-material/EqualizerRounded";',
  },
  {
    id: 5,
    name: "DirectionsCarIcon",
    txt: "업무차량",
    impoTxt:
      'import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";',
  },
  {
    id: 6,
    name: "ReorderRoundedIcon",
    txt: "기초정보관리",
    impoTxt:
      'import ReorderRoundedIcon from "@mui/icons-material/ReorderRounded";',
  },
  {
    id: 7,
    name: "ArticleRoundedIcon",
    txt: "전표관리",
    impoTxt:
      'import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";',
  },
  {
    id: 8,
    name: "SettingsRoundedIcon",
    txt: "관리자설정/사용자설정",
    impoTxt:
      'import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";',
  },
  {
    id: 9,
    name: "InsertDriveFileOutlinedIcon",
    txt: "Documentation",
    impoTxt:
      'import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";',
  },
];

const iconBreadcrumbsList = [
  {
    id: 1,
    name: "SpaceDashboardIcon",
    txt: "HOME",
    impoTxt:
      'import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";',
  },
  {
    id: 2,
    name: "CampaignIcon",
    txt: "현재 위치",
    impoTxt: 'import CampaignIcon from "@mui/icons-material/Campaign";',
  },
];

const iconImgList = [
  {
    id: 1,
    name: "Receipt",
    txt: "[경비]전체/사용내역 미작성",
    impoTxt:
      'import Receipt from "@untitled-ui/icons-react/build/esm/Receipt";',
  },
  {
    id: 2,
    name: "ReceiptCheck",
    txt: "[경비]사용내역 작성",
    impoTxt: 'import { ReceiptCheck } from "@untitled-ui/icons-react";',
  },
  {
    id: 3,
    name: "CreditCardRoundedIcon",
    txt: "[대시보드]법인카드",
    impoTxt:
      'import CreditCardRoundedIcon from "@mui/icons-material/CreditCardRounded";',
  },
  {
    id: 4,
    name: "ContactEmergencyOutlinedIcon",
    txt: "[대시보드]개인카드",
    impoTxt:
      'import ContactEmergencyOutlinedIcon from "@mui/icons-material/ContactEmergencyOutlined";',
  },
  {
    id: 5,
    name: "ReceiptLongOutlinedIcon",
    txt: "[대시보드]기타증빙",
    impoTxt:
      'import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";',
  },
];

const Icons2 = (props: IconsProps) => {
  return (
    <>
      <div>
        <h3 className={styles.heading3}>2-1. 공통 아이콘</h3>
        <List className={styles.list}>
          {iconList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {/* 동적으로 아이콘  */}
                  {icon.name === "SearchSm" && (
                    <SearchSm className="bp-icon medium" />
                  )}
                  {icon.name === "ArrowLeft" && (
                    <ArrowLeft className="bp-icon medium" />
                  )}
                  {icon.name === "ArrowRight" && (
                    <ArrowRight className="bp-icon medium" />
                  )}
                  {icon.name === "ChevronLeft" && (
                    <ChevronLeft className="bp-icon medium" />
                  )}
                  {icon.name === "ChevronRight" && (
                    <ChevronRight className="bp-icon medium" />
                  )}
                  {icon.name === "DotsHorizontal" && (
                    <DotsHorizontal className="bp-icon medium" />
                  )}
                  {icon.name === "PriorityHighRoundedIcon" && (
                    <PriorityHighRoundedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "SyncRoundedIcon" && (
                    <SyncRoundedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "CheckRounded" && (
                    <CheckRounded className="bp-icon medium" />
                  )}
                  {icon.name === "PauseRoundedIcon" && (
                    <PauseRoundedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "PauseCircleOutlinedIcon" && (
                    <PauseCircleOutlinedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "PersonIcon" && (
                    <PersonIcon className="bp-icon icon-avatar medium" />
                  )}
                  {icon.name === "AltRouteRoundedIcon" && (
                    <AltRouteRoundedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "DotsVertical" && (
                    <DotsVertical className="bp-icon medium" />
                  )}
                  {icon.name === "Download02" && (
                    <Download02 className="bp-icon medium" />
                  )}
                  {icon.name === "Bookmark" && (
                    <Bookmark className="bp-icon medium" />
                  )}
                  {icon.name === "Printer" && (
                    <Printer className="bp-icon medium" />
                  )}
                  {icon.name === "Edit02" && (
                    <Edit02 className="bp-icon medium" />
                  )}
                  {icon.name === "FilterFunnel01" && (
                    <FilterFunnel01 className="bp-icon medium" />
                  )}
                  {icon.name === "Settings02" && (
                    <Settings02 className="bp-icon medium" />
                  )}
                  {icon.name === "StickerCircle" && (
                    <StickerCircle className="bp-icon medium" />
                  )}
                  {icon.name === "Settings04" && (
                    <Settings04 className="bp-icon medium" />
                  )}
                  {icon.name === "MinusCircle" && (
                    <MinusCircle className="bp-icon medium" />
                  )}
                  {icon.name === "Upload01" && (
                    <Upload01 className="bp-icon medium" />
                  )}
                  {icon.name === "Image03" && (
                    <Image03 className="bp-icon medium" />
                  )}
                  {icon.name === "Share07" && (
                    <Share07 className="bp-icon medium" />
                  )}
                  {icon.name === "SlashOctagon" && (
                    <SlashOctagon className="bp-icon medium" />
                  )}
                  {icon.name === "File05" && (
                    <File05 className="bp-icon medium" />
                  )}
                  {icon.name === "UserPlus01" && (
                    <UserPlus01 className="bp-icon medium" />
                  )}
                  {icon.name === "Building05" && (
                    <Building05 className="bp-icon medium" />
                  )}
                  {icon.name === "Users03" && (
                    <Users03 className="bp-icon medium" />
                  )}
                  {icon.name === "Plus" && <Plus className="bp-icon medium" />}
                  {icon.name === "Minus" && (
                    <Minus className="bp-icon medium" />
                  )}
                  {icon.name === "Trash02" && (
                    <Trash02 className="bp-icon medium" />
                  )}
                  {icon.name === "Clock" && (
                    <Clock className="bp-icon medium" />
                  )}
                  {icon.name === "ApprovalRoundedIcon" && (
                    <ApprovalRoundedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "ParagraphSpacing" && (
                    <ParagraphSpacing className="bp-icon medium" />
                  )}
                  {icon.name === "Expand01" && (
                    <Expand01 className="bp-icon medium" />
                  )}
                  {icon.name === "XCircle" && (
                    <XCircle className="bp-icon medium" />
                  )}
                  {icon.name === "PencilLine" && (
                    <PencilLine className="bp-icon medium" />
                  )}
                  {icon.name === "Pencil02" && (
                    <Pencil02 className="bp-icon medium" />
                  )}
                  {icon.name === "FileSearch02" && (
                    <FileSearch02 className="bp-icon medium" />
                  )}
                  {icon.name === "XSquare" && (
                    <XSquare className="bp-icon medium" />
                  )}
                  {icon.name === "RefreshCcw01" && (
                    <RefreshCcw01 className="bp-icon medium" />
                  )}
                  {icon.name === "Download01" && (
                    <Download01 className="bp-icon medium" />
                  )}
                  {icon.name === "WifiProtectedSetupOutlinedIcon" && (
                    <WifiProtectedSetupOutlinedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "FolderPlus" && (
                    <FolderPlus className="bp-icon medium" />
                  )}
                  {icon.name === "MessageAlertCircle" && (
                    <MessageAlertCircle className="bp-icon medium" />
                  )}
                  {icon.name === "ClipboardCheck" && (
                    <ClipboardCheck className="bp-icon medium" />
                  )}
                  {icon.name === "RefreshCcw04" && (
                    <RefreshCcw04 className="bp-icon medium" />
                  )}
                  {icon.name === "FileCheck01" && (
                    <FileCheck01 className="bp-icon medium" />
                  )}
                  {icon.name === "Columns02" && (
                    <Columns02 className="bp-icon medium" />
                  )}
                  {icon.name === "UserCheck01" && (
                    <UserCheck01 className="bp-icon medium" />
                  )}
                  {icon.name === "Copy06" && (
                    <Copy06 className="bp-icon medium" />
                  )}
                  {icon.name === "ReverseLeft" && (
                    <ReverseLeft className="bp-icon medium" />
                  )}
                  {icon.name === "Paperclip" && (
                    <Paperclip className="bp-icon medium" />
                  )}
                  {icon.name === "ChevronDown" && (
                    <ChevronDown className="bp-icon medium" />
                  )}
                  {icon.name === "ChevronUp" && (
                    <ChevronUp className="bp-icon medium" />
                  )}
                  {icon.name === "ArrowDropDownIcon" && (
                    <ArrowDropDownIcon className="bp-icon medium" />
                  )}
                  {icon.name === "Link03" && (
                    <Link03 className="bp-icon medium" />
                  )}
                  {icon.name === "Bell01" && (
                    <Bell01 className="bp-icon medium" />
                  )}
                  {icon.name === "Globe02" && (
                    <Globe02 className="bp-icon medium" />
                  )}
                  {icon.name === "FaceId" && (
                    <FaceId className="bp-icon medium" />
                  )}
                  {icon.name === "Edit05" && (
                    <Edit05 className="bp-icon medium" />
                  )}

                  {icon.name === "File02" && (
                    <File02 className="bp-icon medium" />
                  )}
                  {icon.name === "UserEdit" && (
                    <UserEdit className="bp-icon medium" />
                  )}
                  {icon.name === "Train" && (
                    <Train className="bp-icon medium" />
                  )}
                  {icon.name === "Bus" && <Bus className="bp-icon medium" />}
                  {icon.name === "Plane" && (
                    <Plane className="bp-icon medium" />
                  )}
                  {icon.name === "Percent03" && (
                    <Percent03 className="bp-icon medium" />
                  )}
                  {icon.name === "Edit03" && (
                    <Edit03 className="bp-icon medium" />
                  )}
                  {icon.name === "Briefcase02" && (
                    <Briefcase02 className="bp-icon medium" />
                  )}
                  {icon.name === "Dotpoints01" && (
                    <Dotpoints01 className="bp-icon medium" />
                  )}
                  {icon.name === "IconBox" && (
                    <IconBox className="bp-icon medium" />
                  )}
                  {icon.name === "FilePlus02" && (
                    <FilePlus02 className="bp-icon medium" />
                  )}
                  {icon.name === "FileCheck02" && (
                    <FileCheck02 className="bp-icon medium" />
                  )}
                  {icon.name === "CreditCardSearch" && (
                    <CreditCardSearch className="bp-icon medium" />
                  )}
                  {icon.name === "FileX03" && (
                    <FileX03 className="bp-icon medium" />
                  )}
                  {icon.name === "ClockSnooze" && (
                    <ClockSnooze className="bp-icon medium" />
                  )}
                  {icon.name === "CreditCardRefresh" && (
                    <CreditCardRefresh className="bp-icon medium" />
                  )}
                  {icon.name === "Bank" && <Bank className="bp-icon medium" />}
                  {icon.name === "Car01" && (
                    <Car01 className="bp-icon medium" />
                  )}
                  {icon.name === "Ticket02" && (
                    <Ticket02 className="bp-icon medium" />
                  )}
                  {icon.name === "Target03" && (
                    <Target03 className="bp-icon medium" />
                  )}
                  {icon.name === "BarChartSquare02" && (
                    <BarChartSquare02 className="bp-icon medium" />
                  )}
                  {icon.name === "MessageDotsCircle" && (
                    <MessageDotsCircle className="bp-icon medium" />
                  )}
                  {icon.name === "Heart" && (
                    <Heart className="bp-icon medium" />
                  )}
                  {icon.name === "Star01" && (
                    <Star01 className="bp-icon medium" />
                  )}
                  {icon.name === "Mark" && <Mark className="bp-icon medium" />}
                  {icon.name === "MarkerPin01" && (
                    <MarkerPin01 className="bp-icon medium" />
                  )}

                  {icon.name === "MessageCheckSquare" && (
                    <MessageCheckSquare className="bp-icon medium" />
                  )}
                  {icon.name === "Home03" && (
                    <Home03 className="bp-icon medium" />
                  )}
                  {icon.name === "LogOut01" && (
                    <LogOut01 className="bp-icon medium" />
                  )}

                  {icon.name === "CreditCardEdit" && (
                    <CreditCardEdit className="bp-icon medium" />
                  )}
                  {icon.name === "UserCircle" && (
                    <UserCircle className="bp-icon medium" />
                  )}
                  {icon.name === "CpuChip01" && (
                    <CpuChip01 className="bp-icon medium" />
                  )}
                  {icon.name === "FileAttachment04" && (
                    <FileAttachment04 className="bp-icon medium" />
                  )}
                  {icon.name === "InfoCircle" && (
                    <InfoCircle className="bp-icon medium" />
                  )}
                  {icon.name === "ListAltRoundedIcon" && (
                    <ListAltRoundedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "LeaderboardOutlinedIcon" && (
                    <LeaderboardOutlinedIcon className="bp-icon medium" />
                  )}
                  {icon.name === "PieChartOutlineIcon" && (
                    <PieChartOutlineIcon className="bp-icon medium" />
                  )}
                  {icon.name === "LinkOff" && (
                    <LinkOff className="bp-icon medium" />
                  )}
                  {icon.name === "Loading01" && (
                    <Loading01 className="bp-icon medium" />
                  )}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
        <h3 className={styles.heading3}>2-2. LNB 메뉴 아이콘</h3>
        <List className={styles.list}>
          {iconLnbList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {/* 동적으로 아이콘  */}
                  {icon.name === "SpaceDashboardIcon" && <SpaceDashboardIcon />}
                  {icon.name === "ReceiptIcon" && <ReceiptIcon />}
                  {icon.name === "ApprovalRoundedIcon" && (
                    <ApprovalRoundedIcon />
                  )}
                  {icon.name === "EqualizerRoundedIcon" && (
                    <EqualizerRoundedIcon />
                  )}
                  {icon.name === "DirectionsCarIcon" && <DirectionsCarIcon />}
                  {icon.name === "ReorderRoundedIcon" && <ReorderRoundedIcon />}
                  {icon.name === "ArticleRoundedIcon" && <ArticleRoundedIcon />}
                  {icon.name === "SettingsRoundedIcon" && (
                    <SettingsRoundedIcon />
                  )}
                  {icon.name === "InsertDriveFileOutlinedIcon" && (
                    <InsertDriveFileOutlinedIcon />
                  )}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
        <h3 className={styles.heading3}>2-3. Breadcrumbs 아이콘</h3>
        <List className={styles.list}>
          {iconBreadcrumbsList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {/* 동적으로 아이콘  */}
                  {icon.name === "SpaceDashboardIcon" && <SpaceDashboardIcon />}
                  {icon.name === "CampaignIcon" && <CampaignIcon />}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
        <h3 className={styles.heading3}>2-4. 아이콘 이미지</h3>
        <h4 className="heading4">2-4-1. 경비</h4>
        <List className={styles.list}>
          {iconImgList.map((icon) => (
            <ListItem key={icon.id} disablePadding>
              <dl className={styles.item}>
                <dt>
                  {icon.name === "Receipt" && <Receipt />}
                  {icon.name === "ReceiptCheck" && <ReceiptCheck />}
                  {icon.name === "CreditCard01" && <CreditCard01 />}
                  {icon.name === "CreditCardRoundedIcon" && (
                    <CreditCardRoundedIcon />
                  )}
                  {icon.name === "ContactEmergencyOutlinedIcon" && (
                    <ContactEmergencyOutlinedIcon />
                  )}
                  {icon.name === "ReceiptLongOutlinedIcon" && (
                    <ReceiptLongOutlinedIcon />
                  )}
                </dt>
                <dd>{icon.txt}</dd>
                <dd className={styles.impoTxt}>{icon.impoTxt}</dd>
                <dd>{`<${icon.name} />`}</dd>
              </dl>
            </ListItem>
          ))}
        </List>
      </div>
    </>
  );
};

export default Icons2;
