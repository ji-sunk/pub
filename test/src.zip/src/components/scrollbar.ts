import { styled } from "@mui/material/styles";
import SimpleBar from "simplebar-react";

export const Scrollbar = styled(SimpleBar)``;
