
const main_ai_slider = new Swiper('.ai_slider', {
  speed: 400,
  loop: true,  
  pagination: {
    el: '.ai_bullets_wrap',
    clickable: true,
    type: 'bullets',       
  }
});
