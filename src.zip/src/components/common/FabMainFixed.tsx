import NorthRoundedIcon from "@mui/icons-material/NorthRounded";
import { Box, Fab } from "@mui/material";
import { Edit05 } from "@untitled-ui/icons-react";
import { FC } from "react";

type Anchor = "top" | "left" | "bottom" | "right";

// or
type FabMainFixedProps = {};
const FabMainFixed: FC<FabMainFixedProps> = () => {
  // [Drawer]
  return (
    <>
      <Box className="floating-area type-main">
        <Fab color="inherit" aria-label="top" className="top-scroll">
          <NorthRoundedIcon fontSize="medium" className="bp-icon medium" />
        </Fab>
        <Fab variant="extended">
          <Edit05 fontSize="small" className="bp-icon small" />
          <Box component="span" className="txt">
            출장계획하기
          </Box>
        </Fab>
      </Box>
    </>
  );
};

export default FabMainFixed;
