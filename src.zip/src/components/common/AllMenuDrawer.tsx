import { Close } from "@mui/icons-material";
import {
  Avatar,
  Box,
  IconButton,
  List,
  ListItem,
  Typography,
} from "@mui/material";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import { ChevronRight, Menu04, Settings02 } from "@untitled-ui/icons-react";
import { ReactNode, useState } from "react";
import { Link } from "react-router-dom";

interface AllMenuDrawerProps {
  children?: ReactNode;
}
const AllMenuDrawer = (props: AllMenuDrawerProps) => {
  // [Drawer]
  const [drawerHeaderHeight, setDrawerHeaderHeight] = useState(0);
  const [isDrawerOpen, setIsDrawerOpen] = useState({
    drawer1: false,
  });
  const toggleDrawer = (drawerId, open) => (event) => {
    if (event && (event.key === "Tab" || event.key === "Shift")) {
      return;
    }

    setIsDrawerOpen({ ...isDrawerOpen, [drawerId]: open });

    if (open) {
      const headerHeight =
        document.getElementById("drawer-header")?.offsetHeight || 0;
      setDrawerHeaderHeight(headerHeight);
    }
  };

  return (
    <>
      <IconButton
        onClick={toggleDrawer("drawer1", true)}
        className="btn-icon-only"
        size="medium"
        aria-label="전체메뉴"
      >
        <Menu04 fontSize="medium" />
      </IconButton>
      <SwipeableDrawer
        anchor="right"
        open={isDrawerOpen.drawer1}
        onClose={toggleDrawer("drawer1", false)}
        onOpen={toggleDrawer("drawer1", true)}
        className="bp-drawer drawer-right bp-allmenu"
      >
        <div className="drawer-header" id="drawer-header">
          <div className="inner">
            <Box className="left-area">
              <Typography variant="h2">전체메뉴</Typography>
            </Box>
            <Box className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="설정"
              >
                <Settings02 fontSize="small" className="bp-icon" />
              </IconButton>
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={toggleDrawer("drawer1", false)}
              >
                <Close fontSize="small" className="bp-icon" />
              </IconButton>
            </Box>
          </div>
        </div>
        <Box className="drawer-body ui-scroll" sx={{}}>
          <Box className="drawer-cont">
            {/* [S]allmenu-wrap */}
            <div className="allmenu-wrap">
              {/* [S]user profile */}
              <div className="item-field">
                <div className="inner-sides">
                  <dl className="item-user-info">
                    <dt className="photo">
                      <Avatar
                        alt="최현대"
                        src="/assets/images/tmp-profile2.png"
                        className="user-avatar"
                      />
                    </dt>
                    <dd>
                      <div className="user-info-row">
                        <div className="user-name">최현대 과장(1341341)</div>
                      </div>
                      <div className="user-info-row">
                        <div className="user-team">라이프디자인팀 (TBCM-1)</div>
                      </div>
                    </dd>
                  </dl>
                  <div className="right-area">
                    <IconButton>
                      <ChevronRight className="bp-icon" />
                    </IconButton>
                  </div>
                </div>
              </div>
              {/* [E]user profile */}

              {/* [S]direct-link */}
              <div className="item-field">
                <div className="direct-link-list">
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">출장계획내역</Box>
                    </Link>
                  </div>
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">예약/결제내역</Box>
                    </Link>
                  </div>
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">정산내역</Box>
                    </Link>
                  </div>
                  <div className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">마이페이지</Box>
                    </Link>
                  </div>
                </div>
                <div className="menu-link-list"></div>
              </div>
              {/* [E]direct-link */}

              {/* [S]menu-list depth-link */}
              <div className="menu-list depth-link-list">
                <List className="depth1">
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">홈</Box>
                    </Link>
                  </ListItem>

                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">출장 계획하기</Box>
                    </Link>
                    <List className="depth2">
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">출장계획서 작성하기</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">출장계획서 대리 작성하기</Box>
                        </Link>
                      </ListItem>
                    </List>
                  </ListItem>

                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">상품 예약하기</Box>
                    </Link>
                    {/* depth2 type-half : 메뉴링크넓이 */}
                    <List className="depth2 type-half">
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">숙박</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">항공</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">KTX</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">SRT</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">고속버스</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">시외버스</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">자기차량</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">법인차/테스트차</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">렌트카</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">택시</Box>
                        </Link>
                      </ListItem>
                      <ListItem className="item">
                        <Link className="item-menu" to="#">
                          <Box className="txt">선박</Box>
                        </Link>
                      </ListItem>
                    </List>
                  </ListItem>

                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">출장비 정산하기</Box>
                    </Link>
                  </ListItem>
                </List>
              </div>
              {/* [E]menu-list depth-link */}

              {/* [S]menu-list footer-link */}
              <div className="menu-list footer-link-list">
                <List className="depth1">
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">출장비 지급 규정 안내</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">공지사항</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">FAQ</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">1:1문의하기</Box>
                    </Link>
                  </ListItem>
                </List>
              </div>
              {/* [E]menu-list footer-link */}

              {/* [S]menu-list security-link */}
              <div className="menu-list security-link-list">
                <List className="depth1">
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">서비스 이용약관</Box>
                    </Link>
                  </ListItem>
                  <ListItem className="item">
                    <Link className="item-menu" to="#">
                      <Box className="txt">개인정보처리방침</Box>
                    </Link>
                  </ListItem>
                </List>
              </div>
              {/* [E]menu-list security-link */}
            </div>
            {/* [E]allmenu-wrap */}
          </Box>
        </Box>
      </SwipeableDrawer>
    </>
  );
};

export default AllMenuDrawer;
