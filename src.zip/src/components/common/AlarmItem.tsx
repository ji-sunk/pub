import {
  Notification,
  NotificationService,
  useNotificationListSWR,
} from "@bizplay/core";
import { Avatar, ListItem, Stack, Typography } from "@mui/material";
// import { useRouter } from "next/router";
import { FC, ReactNode } from "react";
import { useNavigate } from "react-router-dom";

type AlarmItemProps = {
  notification: Notification;
  icon?: ReactNode;
};
const AlarmItem: FC<AlarmItemProps> = (props) => {
  const { notification, icon } = props;

  // const router = useRouter();
  const navigate = useNavigate();
  const { notifications, mutate } = useNotificationListSWR();

  const handleClick = async () => {
    if (notification.readStatus) {
      return;
    }

    try {
      await NotificationService.read(notification.id);
    } catch (e) {
      // 알림 받고 공지사항이 삭제된 경우 Error 발생
    }

    updateNotificationReadStatus();

    if (notification.notificationActionType === "NAVIGATE") {
      // router.push(notification.notificationActionData);
      navigate(notification.notificationActionData);
    }
  };

  const updateNotificationReadStatus = () => {
    const newNotifications = notifications.map((value) => {
      if (value.id === notification.id) {
        return {
          ...value,
          readStatus: true,
        };
      }

      return value;
    });

    mutate(newNotifications, false);
  };

  return (
    <ListItem
      sx={{
        py: 1,
        px: 2,
        cursor: "pointer",
        bgcolor: notification.readStatus ? "" : "#1A32F61A",
      }}
      onClick={handleClick}
    >
      <Stack direction="row" alignItems="center">
        <Avatar sx={{ mr: 2, bgcolor: "primary.main" }}>{icon}</Avatar>
        <Stack>
          <Typography variant="h2">{notification.title}</Typography>
          <Typography variant="body2">{notification.content}</Typography>
        </Stack>
      </Stack>
    </ListItem>
  );
};

export default AlarmItem;
