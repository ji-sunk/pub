import {
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
} from "@mui/material";
import { useState } from "react";

const RadioList = () => {
  // [Drawer]
  const [RadioValueCard, setRadioValueCard] = useState("radioCard-01");
  const handleChangeradioCard = (event) => {
    setRadioValueCard(event.target.value);
  };

  return (
    <>
      <div className="selected-list">
        <FormControl
          component="fieldset"
          variant="standard"
          className="fullWidth"
        >
          <RadioGroup
            aria-labelledby="radio-buttons-group"
            defaultValue="radioCard-01"
            name="radio buttons group"
            value={RadioValueCard}
            className="bp-btns-group fullWidth list-radio"
            onChange={handleChangeradioCard}
            row
          >
            <FormControlLabel
              className={`btn-form-type ${
                RadioValueCard === "radioCard-01" ? "is-active" : ""
              }`}
              control={<Radio value="radioCard-01" />}
              label="TBCM-1 (잔액 : 10,000,000원)"
            />
            <FormControlLabel
              className={`btn-form-type ${
                RadioValueCard === "radioCard-02" ? "is-active" : ""
              }`}
              control={<Radio value="radioCard-02" />}
              label="TBCM-2 (잔액 : 0원)"
            />
            <FormControlLabel
              className={`btn-form-type ${
                RadioValueCard === "radioCard-03" ? "is-active" : ""
              }`}
              control={<Radio value="radioCard-03" />}
              label="TBCM-3 (잔액 : 10,000,000원)"
            />
          </RadioGroup>
        </FormControl>
      </div>
    </>
  );
};

export default RadioList;
