import {
  AppBar,
  Box,
  Button,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";

import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";

const MLG010103 = () => {
  const [selected, setSelected] = React.useState(false);
  // [팝업]기본 팝업
  const [openDialog, setOpenDialog] = React.useState(false);
  const [scroll, setScroll] = React.useState<DialogProps["scroll"]>("paper");
  const handleClickOpenDialog = (scrollType: DialogProps["scroll"]) => () => {
    setOpenDialog(true);
    setScroll(scrollType);
  };

  const descriptionElementRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    if (openDialog) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openDialog]);

  // [팝업]FullPaper
  const [OpenFullPaper, setOpenFullPaper] = React.useState(false);
  const handleClickOpenFullPaper =
    (scrollType: DialogProps["scroll"]) => () => {
      setOpenFullPaper(true);
      setScroll(scrollType);
    };
  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);
  return (
    <>
      <Head>
        <title>개인정보 수집 이용 취급 위탁동의</title>
      </Head>
      {/* [S]개인정보 수집 이용 취급 위탁동의 */}
      <Dialog
        fullScreen
        open
        //   open={OpenFullPaper}
        onClose={handleCloseFullPaper}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          {/* [S]<HeaderDialog /> */}
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography variant="h3">
                  개인정보 수집 이용 취급 위탁동의
                </Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseFullPaper}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
          {/* [E]HeaderDialog */}
        </DialogTitle>
        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner">
            {/* [S]terms-details */}
            <div className="terms-details">
              <p className="text-hide">개인정보 수집 이용 취급 위탁동의</p>
              <div>
                (주)코리아크레딧뷰로(이하 “회사”라고 한다)가 제공하는
                “본인확인서비스” 의 휴대폰 본인확인과 관련하여 본인으로부터
                취득한 개인정보는 "정보통신망이용촉진 및 정보보호등에 관한 법률"
                및 "신용정보의 이용 및 보호에 관한 법률"에 따라 본인의 동의를
                얻어 다음의 목적을 위해 제공 및 이용 됩니다.
              </div>
              <ul>
                <li>
                  <p>[개인정보의 수집 및 이용 목적]</p>
                  <div>
                    “회사”는 생년월일과 휴대폰번호 일치 여부 및 휴대폰 점유
                    확인과 휴대폰 번호보호 서비스를 안내하기 위한 목적으로
                    아래의 회사에 다음의 정보를 이용 및 제공합니다.
                  </div>
                  <ol>
                    <li>
                      <div className="box">
                        <span className="num">①</span> 이용 및 제공 정보
                      </div>
                      <div className="box-indent">
                        - 휴대폰번호, 통신사정보, 생년월일, 성명, 성별, 내외국인
                        정보
                      </div>
                    </li>
                    <li>
                      <div className="box">
                        <span className="num">②</span> 제공사
                      </div>
                      <div className="box-indent">
                        - SKT, KT, LG U+, 드림시큐리티, 스탠다드네트웍스,
                        인포뱅크 및 본인확인 서비스 요청 사업자
                      </div>
                    </li>
                  </ol>
                </li>
                <li>
                  <p>[개인정보의 보유 및 이용기간]</p>
                  <div>
                    "회사"는 이용자의 개인정보를 이용목적이 달성되거나 보유 및
                    보존기간이 종료하면 해당 정보를 지체없이 파기 하며 별도의
                    보관을 하지 않습니다. 단, 관련 법령 및 회사방침에 따라
                    보존하는 목적과 기간은 아래와 같습니다.
                  </div>
                </li>
                <li>
                  <p>[관련법령에 의한 정보보유 사유]</p>
                  <div>
                    정보통신망 이용촉진 및 정보보호 등에 관한 법률과 신용정보의
                    이용 및 보호에 관한 법률 등 관계법령의 규정에 의하여 보존할
                    필요가 있는 경우 회사는 관계법령에서 정한 일정한 기간 동안
                    회원정보를 보관합니다. 이 경우 회사는 보관하는 정보를 그
                    보관의 목적으로만 이용하며 보존기간은 아래와 같습니다.
                  </div>
                  <ol>
                    <li>
                      <span className="num">①</span> 정보통신망 이용촉진 및
                      정보보호 등에 관한 법률과 신용정보의 이용 및 보호의 관한
                      법률에 의거 정보 보존 기간: 3년
                    </li>
                    <li>
                      <span className="num">②</span> 회사 내부 방침에 의하여
                      부정이용방지를 위한 정보 보존기간: 5년
                    </li>
                    <li>
                      <span className="num">③</span> 소비자의 불만 또는
                      분쟁처리에 관한 기록: 3년(전자상거래등에서의 소비자보호에
                      관한 법률)
                    </li>
                  </ol>
                </li>
                <li>
                  <div className="box-indent">
                    ※ 본 개인정보 수집 이용동의는 거부할 수 있으나, 거부 시에는
                    휴대폰본인확인서비스를 제공받으실 수 없습니다.
                  </div>
                </li>
              </ul>
            </div>
            {/* [E]terms-details */}
          </div>
        </DialogContent>
        <DialogActions className="dialog-footer">
          {/* [S]<BtnsGroup /> */}
          <Box className="btns-group">
            <Box className="inner">
              <Button variant="contained" size="large" className="btn-xlarge">
                {/* 240819 modify */}
                동의하기
              </Button>
            </Box>
          </Box>
          {/* [E]BtnsGroup */}
        </DialogActions>
      </Dialog>
      {/* [E]bizplay이용약관 */}
    </>
  );
};

export default MLG010103;
