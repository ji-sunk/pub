import { Close } from "@mui/icons-material";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  IconButton,
  Paper,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from "@mui/material";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import { useState } from "react";
import { Helmet as Head } from "react-helmet";

type Anchor = "top" | "left" | "bottom" | "right";

const ListDrawer = () => {
  // [Drawer]
  const [drawerHeaderHeight, setDrawerHeaderHeight] = useState(0);
  const [RadioValueCard, setRadioValueCard] = useState("radioCard-01");
  const handleChangeradioCard = (event) => {
    setRadioValueCard(event.target.value);
  };
  const [isDrawerOpen, setIsDrawerOpen] = useState({
    listDrawer: false, //list
  });
  const toggleDrawer = (drawerId, open) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setIsDrawerOpen({ ...isDrawerOpen, [drawerId]: open });

    if (open) {
      const headerHeight =
        document.getElementById("drawer-header")?.offsetHeight || 0;
      setDrawerHeaderHeight(headerHeight);
    }
  };

  return (
    <>
      <Head>
        <title>출장목적선택 | 출장</title>
      </Head>
      <Button onClick={toggleDrawer("listDrawer", true)}>[출장목적선택]</Button>
      <SwipeableDrawer
        anchor="bottom"
        open
        onClose={toggleDrawer("listDrawer", false)}
        onOpen={toggleDrawer("listDrawer", true)}
        className="bp-drawer drawer-bottom"
      >
        <div className="drawer-header" id="drawer-header">
          <div className="inner">
            <Box className="left-area"></Box>
            <Box className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={toggleDrawer("listDrawer", false)}
              >
                <Close fontSize="small" className="bp-icon" />
              </IconButton>
            </Box>
          </div>
          <div className="inner">
            <Box className="left-area">
              <Typography variant="h2">출장목적 선택</Typography>
              {/* <Box component="p" className="txt-desc"></Box> */}
            </Box>
          </div>
        </div>
        <Paper className="drawer-body">
          <Box className="drawer-cont">
            <div className="box-inner">
              <FormControl
                component="fieldset"
                variant="standard"
                className="fullWidth"
              >
                <RadioGroup
                  aria-labelledby="radio-buttons-group"
                  defaultValue="radioCard-01"
                  name="radio buttons group"
                  value={RadioValueCard}
                  className="bp-btns-group fullWidth list-radio"
                  onChange={handleChangeradioCard}
                  row
                >
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-01" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-01" />}
                    label="일반출장"
                  />
                  {/* MDF010100_계획서상세_취소사유_입력 */}
                  <TextField
                    variant="filled"
                    size="medium"
                    label="사유"
                    fullWidth
                  />
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-02" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-02" />}
                    label="파견"
                  />
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-03" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-03" />}
                    label="교육출장"
                  />
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-04" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-04" />}
                    label="경조사"
                  />
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-05" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-05" />}
                    label="해외출장"
                  />
                  <FormControlLabel
                    className={`btn-form-type ${
                      RadioValueCard === "radioCard-06" ? "is-active" : ""
                    }`}
                    control={<Radio value="radioCard-06" />}
                    label="현지 시험비 정산"
                  />
                </RadioGroup>
              </FormControl>
            </div>
            {/* 하단 버튼 주석 해제 */}
            {/* <Box className="btns-group">
              <Box className="inner">
                <Button variant="contained" size="large">
                  확인
                </Button>
              </Box>
            </Box> */}
          </Box>
        </Paper>
      </SwipeableDrawer>
    </>
  );
};

export default ListDrawer;
