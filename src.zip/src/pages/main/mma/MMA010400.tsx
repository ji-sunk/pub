import { Box, Button, Chip, Paper } from "@mui/material";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";

const MMA010400 = () => {
  return (
    <>
      <Head>
        <title>목적지 주변 검색</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper" , flex-wrap */}
        <Paper className="ui-paper flex-wrap">
          {/* [S]map-route-wrap */}
          <div className="search-around-area">
            <div className="light-box">
              <div className="horizontal-scrolling">
                <div className="list-chip-label">
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    aria-selected="true"
                    label="아산공장1영업소"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    label="아산공장1영업소"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    label="아산공장1영업소"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-rounded"
                    clickable
                  />
                </div>
              </div>
              <div className="horizontal-scrolling">
                <div className="list-chip-label type-medium">
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                  <Chip
                    aria-selected="true"
                    label="아산공장1영업소"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                  <Chip
                    label="아산공장1영업소"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                  <Chip
                    label="양재본사"
                    size="medium"
                    variant="outlined"
                    className="bp-chip type-radius"
                    clickable
                  />
                </div>
              </div>
            </div>
            <div className="light-box full-height">
              <div className="ui-inner">
                <div className="iframe-area">{/* <div>api영역</div> */}</div>
              </div>
            </div>
          </div>
          {/* [E]map-route-wrap */}
        </Paper>
        {/* [E]ui-paper flex-wrap */}
        <Box className="btns-group">
          <Box className="inner">
            <Button variant="contained" size="large" className="btn-xlarge">
              지도에서 검색
            </Button>
          </Box>
        </Box>
      </LayoutSub>
    </>
  );
};

export default MMA010400;
