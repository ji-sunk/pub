import { ArrowDropDown } from "@mui/icons-material";
import AltRouteRoundedIcon from "@mui/icons-material/AltRouteRounded";
import CancelIcon from "@mui/icons-material/Cancel";
import ListAltRoundedIcon from "@mui/icons-material/ListAltRounded";
import {
  Box,
  Button,
  ClickAwayListener,
  FormHelperText,
  Grow,
  IconButton,
  MenuItem,
  MenuList,
  Paper,
  Popper,
  TextField,
} from "@mui/material";
import { useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";

const MDO010500 = () => {
  /* Dropdown 버튼 */
  const [writeOpen, setWriteOpen] = useState(false);
  const [modifyOpen, setModifyOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);
  const modifyAnchorRef = useRef<HTMLButtonElement>(null);

  const handleWriteOpen = () => {
    setWriteOpen((prevOpen) => !prevOpen);
  };

  const handleModifyOpen = () => {
    setModifyOpen((prevOpen) => !prevOpen);
  };

  const handleWriteClose = (event: Event | React.SyntheticEvent) => {
    if (
      writeAnchorRef.current &&
      writeAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setWriteOpen(false);
  };

  const handleModifyClose = (event: Event | React.SyntheticEvent) => {
    if (
      modifyAnchorRef.current &&
      modifyAnchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setModifyOpen(false);
  };

  function handleListKeyDown(event: React.KeyboardEvent) {
    if (event.key === "Tab") {
      event.preventDefault();
      setWriteOpen(false);
      setModifyOpen(false);
    } else if (event.key === "Escape") {
      setWriteOpen(false);
      setModifyOpen(false);
    }
  }

  // 버튼 file
  const fileInputRef1 = useRef(null);
  const fileInputRef2 = useRef(null);
  const fileInputRef3 = useRef(null);

  //const [fileUrl, setFileUrl] = useState("");
  const [fileName, setFileName] = useState("");
  const [fileImages, setFileImages] = useState([
    { src: "../../../../assets/images/no-img.svg", alt: "", isDefault: true },
  ]);

  const handleFileChange2 = (event) => {
    const file = event.target.files[0];
    if (file) {
      /* 파일 경로
     const fileUrl = URL.createObjectURL(file);
     setFileUrl(fileUrl);
     */
      setFileName(file.name);
    }
  };

  const handleFileChange3 = (event) => {
    const files = event.target.files;
    if (files.length > 0) {
      const newImages = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();
        reader.onload = (e) => {
          newImages.push({ src: e.target.result, isDefault: false });
          if (newImages.length === files.length) {
            setFileImages(newImages); // 기본 이미지를 초기화하고 새로운 이미지를 추가
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleImageDelete = (index) => {
    setFileImages((prevImages) => prevImages.filter((_, i) => i !== index));
  };
  return (
    <>
      <Head>
        <title>정산정보입력 | 정산서</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper" , bztrip-wrap */}
        <Paper className="ui-paper bztrip-wrap">
          {/* [S] */}
          <div className="light-box full-height">
            {/* [S]fields-group  */}
            <div className="fields-group">
              {/* [S]fields-group */}
              <div className="fields-group">
                <div className="ui-box type-line">
                  <div className="item-card">
                    <div className="item">
                      <div className="item-top inner-sides">
                        <div className="left-area">
                          <Box className="btn-dropdown">
                            <Button
                              className="btn-arrow-dropdown"
                              variant="outlined"
                              size="small"
                              id="modify-button"
                              onClick={handleModifyOpen}
                              ref={modifyAnchorRef}
                              aria-controls={
                                modifyOpen ? "modify-menu" : undefined
                              }
                              aria-expanded={modifyOpen ? "true" : undefined}
                              aria-haspopup="true"
                              endIcon={
                                <ArrowDropDown
                                  fontSize="medium"
                                  className="bp-icon"
                                />
                              }
                            >
                              숙박비
                            </Button>
                            <Popper
                              open={modifyOpen}
                              anchorEl={modifyAnchorRef.current}
                              role={undefined}
                              placement="bottom-start"
                              transition
                              disablePortal
                              className="popper-dropdown fullWidth"
                            >
                              {({ TransitionProps, placement }) => (
                                <Grow
                                  {...TransitionProps}
                                  style={{
                                    transformOrigin:
                                      placement === "bottom-start"
                                        ? "left top"
                                        : "left bottom",
                                  }}
                                >
                                  <Paper>
                                    <ClickAwayListener
                                      onClickAway={handleModifyClose}
                                    >
                                      <MenuList
                                        autoFocusItem={modifyOpen}
                                        id="modify-menu"
                                        aria-labelledby="modify-button"
                                        onKeyDown={handleListKeyDown}
                                      >
                                        <MenuItem onClick={handleModifyClose}>
                                          수정하기
                                        </MenuItem>
                                        <MenuItem onClick={handleModifyClose}>
                                          분할하기
                                        </MenuItem>
                                        <MenuItem onClick={handleModifyClose}>
                                          세액수정
                                        </MenuItem>
                                      </MenuList>
                                    </ClickAwayListener>
                                  </Paper>
                                </Grow>
                              )}
                            </Popper>
                          </Box>
                        </div>
                        <div className="right-area">
                          <IconButton size="small" className="btn-clear">
                            <CancelIcon
                              fontSize="small"
                              className="bp-icon small"
                            />
                          </IconButton>
                        </div>
                      </div>
                      <div className="item-top inner-sides">
                        <div className="left-area">
                          <div className="list-schedule">
                            <Box className="txt-period">
                              2024.04.08 ~ 2024.04.12
                            </Box>
                            <Box className="txt-term">(4박5일)</Box>
                          </div>
                        </div>
                        <div className="right-area">
                          <div className="item-date">결제일시 04.12 12:00</div>
                        </div>
                      </div>
                      <div className="title-area inner-sides">
                        <div className="txt">울산 1공장 방문건</div>
                        <div className="right-area type-amount">
                          <div className="number-area">
                            <Box className="flex-row">
                              <span className="txt">결제금액</span>
                              <Box component="span" className="point-large">
                                295,000
                                <span className="txt-currency">원</span>
                              </Box>
                            </Box>
                            <Box>
                              <div className="txt-desc">
                                출장비 지원 53,000원
                              </div>
                            </Box>
                            <FormHelperText className="color-error">
                              출장기간과 이용기간이 맞지 않습니다.
                            </FormHelperText>
                            <Box>
                              <div className="txt-desc">
                                회수금액
                                <span className="color-error">-53,000원</span>
                              </div>
                            </Box>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="ui-box type-line">
                  <div className="item-card">
                    <div className="item">
                      <div className="item-top inner-sides">
                        <div className="left-area">
                          <Button
                            className="btn-arrow-dropdown"
                            variant="outlined"
                            size="small"
                            id="modify-button"
                            onClick={handleModifyOpen}
                            ref={modifyAnchorRef}
                            aria-controls={
                              modifyOpen ? "modify-menu" : undefined
                            }
                            aria-expanded={modifyOpen ? "true" : undefined}
                            aria-haspopup="true"
                            endIcon={
                              <ArrowDropDown
                                fontSize="medium"
                                className="bp-icon"
                              />
                            }
                          >
                            숙박비
                          </Button>
                        </div>
                        <div className="right-area">
                          <IconButton size="small" className="btn-clear">
                            <ListAltRoundedIcon
                              fontSize="small"
                              className="bp-icon small"
                            />
                          </IconButton>
                          <IconButton
                            className="btn-icon-only"
                            size="small"
                            aria-label="분할"
                          >
                            <AltRouteRoundedIcon
                              fontSize="small"
                              className="bp-icon xsmall"
                            />
                          </IconButton>
                          <IconButton size="small" className="btn-clear">
                            <CancelIcon
                              fontSize="small"
                              className="bp-icon small"
                            />
                          </IconButton>
                        </div>
                      </div>
                      <div className="item-top inner-sides">
                        <div className="left-area">
                          <div className="list-schedule">
                            <Box className="txt-period">
                              2024.04.08 ~ 2024.04.12
                            </Box>
                            <Box className="txt-term">(4박5일)</Box>
                          </div>
                        </div>
                        <div className="right-area">
                          <div className="item-date">결제일시 04.12 12:00</div>
                        </div>
                      </div>
                      <div className="title-area inner-sides">
                        <div className="txt">울산 1공장 방문건</div>
                        <div className="right-area type-amount">
                          <div className="number-area">
                            <Box className="flex-row">
                              <span className="txt">결제금액</span>
                              <Box component="span" className="point-large">
                                295,000
                                <span className="txt-currency">원</span>
                              </Box>
                            </Box>
                            <Box>
                              <div className="txt-desc">
                                출장비 지원 53,000원
                              </div>
                            </Box>
                            <FormHelperText className="color-error">
                              출장기간과 이용기간이 맞지 않습니다.
                            </FormHelperText>
                            <Box>
                              <div className="txt-desc">
                                회수금액
                                <span className="color-error">-53,000원</span>
                              </div>
                            </Box>
                          </div>
                        </div>
                      </div>
                      <div className="item-field">
                        <TextField
                          size="small"
                          hiddenLabel
                          placeholder=""
                          fullWidth
                          value="200,000 원"
                          InputProps={{
                            inputProps: {
                              style: { textAlign: "right" },
                            },
                          }}
                        />
                        <FormHelperText className="color-error align-right">
                          출장기간과 이용기간이 맞지 않습니다.
                        </FormHelperText>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* [E]fields-group */}
            </div>
            {/* [E]fields-group view-plan */}
            <Box className="txt-btns-group">
              <Button size="medium">영수증 첨부</Button>
            </Box>
          </div>
          {/* [E] */}
        </Paper>
        {/* [E]ui-paper bztrip-wrap */}
        <Box className="btns-group">
          <Box className="inner">
            <Button
              variant="contained"
              size="large"
              className="btn-xlarge color-neutral"
            >
              이전
            </Button>
            <Button variant="contained" size="large" className="btn-xlarge">
              다음
            </Button>
          </Box>
        </Box>
      </LayoutSub>
    </>
  );
};

export default MDO010500;
