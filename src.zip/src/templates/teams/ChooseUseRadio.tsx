import StarRateRoundedIcon from "@mui/icons-material/StarRateRounded";
import {
  FormControl,
  FormLabel,
  Radio,
  RadioGroup,
  ToggleButton,
} from "@mui/material";
import { useGridApiRef } from "@mui/x-data-grid-premium";
import * as React from "react";
import { useState } from "react";

interface Row {
  id: number;
  path: string[];
}

const ChooseUseRadio = () => {
  const [RadioValue02, setRadioValue02] = useState("radio02-01");
  const handleChangeRadio02 = (event) => {
    setRadioValue02(event.target.value);
  };
  /* Toggle 버튼 */
  const [selected, setSelected] = React.useState(false);
  const [selected2, setSelected2] = React.useState(true);
  const apiRef = useGridApiRef();

  return (
    <>
      <div className="select-area-flex">
        <FormControl>
          <RadioGroup
            aria-labelledby="radio-buttons-group"
            defaultValue="radio0"
            name="radio buttons group"
            value={RadioValue02}
            onChange={handleChangeRadio02}
            className="bp-form-group"
          >
            <FormLabel
              className={`bp-label ${
                RadioValue02 === "radio02-01" ? "is-active" : ""
              }`}
            >
              <Radio value="radio02-01" />
              <dl className="item-label">
                <dt className="title">점심식대</dt>
                <dd>
                  이 부분이 길어져도 모두 보여주어야 합니다 길어져도 다 보여줘요
                  | 2303_0032525252525 252552523525
                </dd>
              </dl>
              <div className="bookmark-area">
                <ToggleButton
                  value="button"
                  selected={selected}
                  onChange={() => {
                    setSelected(!selected);
                  }}
                  className="btn-icon-toggle icon-bookmark"
                >
                  <StarRateRoundedIcon fontSize="medium" />
                </ToggleButton>
              </div>
            </FormLabel>
            <FormLabel
              className={`bp-label ${
                RadioValue02 === "radio02-02" ? "is-active" : ""
              }`}
            >
              <Radio value="radio02-02" />
              <dl className="item-label">
                <dt className="title">
                  텍스트는 전체 노출 글자가 길어질 경우 줄바꿈 처리
                </dt>
                <dd>저녁식대</dd>
              </dl>
              <div className="bookmark-area">
                <ToggleButton
                  value="button"
                  selected={selected2}
                  onChange={() => {
                    setSelected2(!selected2);
                  }}
                  className="btn-icon-toggle icon-bookmark"
                >
                  <StarRateRoundedIcon fontSize="medium" />
                </ToggleButton>
              </div>
            </FormLabel>
          </RadioGroup>
        </FormControl>
      </div>
    </>
  );
};

export default ChooseUseRadio;
