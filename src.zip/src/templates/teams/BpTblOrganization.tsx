import StarRateRoundedIcon from "@mui/icons-material/StarRateRounded";
import { Box, Stack, ToggleButton, Typography } from "@mui/material";
import {
  DataGridPremium,
  GridColDef,
  useGridApiRef,
} from "@mui/x-data-grid-premium";
import * as React from "react";

interface Row {
  id: number;
  path: string[];
}

const BpTblOrganization = () => {
  /* Toggle 버튼 */
  const [selected, setSelected] = React.useState<string[]>([]); // 선택된 행의 ID를 문자열 배열로 관리
  const getRowHeightStandard = (params) => {
    return 44;
  };

  const apiRef = useGridApiRef();

  const columns: GridColDef[] = [
    {
      field: "tblField00",
      headerName: "",
      width: 40,
      renderCell: (params) => {
        // 각 행의 고유한 ID 가져오기
        const rowId = params.id.toString();

        return (
          <>
            <ToggleButton
              value="check"
              selected={selected.includes(rowId)} // 선택된 행을 표시하기 위해 상태 배열에 행 ID가 포함되어 있는지 확인
              onChange={() => {
                // 선택된 행이 이미 있는지 확인하고 행 ID를 추가 또는 제거하여 토글
                if (selected.includes(rowId)) {
                  setSelected(selected.filter((id) => id !== rowId));
                } else {
                  setSelected([...selected, rowId]);
                }
              }}
              className="btn-icon-toggle icon-bookmark"
            >
              <StarRateRoundedIcon fontSize="medium" />
            </ToggleButton>
          </>
        );
      },
      cellClassName: "cell-bookmark",
      minWidth: 40,
      maxWidth: 40,
      type: "singleSelect",
    },
  ];

  const rows = [
    {
      id: 1,
      path: ["비서실"],
    },
    {
      id: 2,
      path: ["인사총무부"],
    },
    {
      id: 3,
      path: ["인사총무부", "인사팀"],
    },
    {
      id: 4,
      path: ["인사총무부", "인사팀", "인사1팀"],
    },
    {
      id: 5,
      path: ["인사총무부", "인사팀", "인사2팀"],
    },
    {
      id: 6,
      path: ["인사총무부", "인사팀", "인사3팀"],
    },
    {
      id: 7,
      path: ["기획부"],
    },
    {
      id: 8,
      path: ["기획부", "기획1팀"],
    },
    {
      id: 9,
      path: ["기획부", "기획2팀"],
    },
    {
      id: 10,
      path: ["4dpt 부서(펼침) 부서명이 긴경우에는 다 보여줘요"],
    },
    {
      id: 11,
      path: ["4dpt 부서(펼침) 부서명이 긴경우에는 다 보여줘요", "기획1팀"],
    },
    {
      id: 12,
      path: ["4dpt 부서(펼침) 부서명이 긴경우에는 다 보여줘요", "기획2팀"],
    },
  ];

  const groupingColDef = {
    headerName: "전체",
  };

  return (
    <>
      <div className="ui-section">
        <Stack spacing={0} className="bp-group-title title-bg">
          <Stack
            spacing={0}
            className="bp-group-title-row bp-group-title-main"
            direction="row"
            justifyContent="space-between"
            alignItems="center"
          >
            <Box className="left">
              <Typography variant="h2" className="bp-title title-sub2">
                선택/인사3팀<strong className="num">5명</strong>
              </Typography>
            </Box>
            <Box className="right"></Box>
          </Stack>
        </Stack>
        <Stack
          spacing={0}
          className="bp-tbl tbl-grid tbl-tree-list fist-bookmark"
        >
          <div>
            <DataGridPremium
              treeData
              getTreeDataPath={(row) => row.path}
              rows={rows}
              columns={columns}
              checkboxSelection
              initialState={{
                pinnedColumns: {
                  left: ["tblField00"], // ToggleButton 고정
                },
              }}
              groupingColDef={groupingColDef}
              defaultGroupingExpansionDepth={-1}
              disableRowSelectionOnClick
              getRowHeight={getRowHeightStandard}
              rowHeight={44}
              apiRef={apiRef}
              hideFooter
            />
          </div>
        </Stack>
      </div>
    </>
  );
};

export default BpTblOrganization;
