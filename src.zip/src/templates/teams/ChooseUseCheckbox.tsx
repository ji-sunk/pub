import StarRateRoundedIcon from "@mui/icons-material/StarRateRounded";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  ToggleButton,
} from "@mui/material";
import { useGridApiRef } from "@mui/x-data-grid-premium";
import * as React from "react";
import { useState } from "react";

interface Row {
  id: number;
  path: string[];
}

const ChooseUseCheckbox = () => {
  const [checked, setChecked] = useState(false);
  const [RadioValue02, setRadioValue02] = useState("radio02-01");
  const handleChangeRadio02 = (event) => {
    setRadioValue02(event.target.value);
  };
  /* Toggle 버튼 */
  const [selected, setSelected] = React.useState(false);
  const [selected2, setSelected2] = React.useState(true);
  const apiRef = useGridApiRef();

  return (
    <>
      <div className="select-area-flex">
        <FormControl>
          <FormGroup className="bp-form-group">
            <FormControlLabel
              className={`${checked ? "is-active" : ""} label-large`}
              control={
                <Checkbox onChange={(e) => setChecked(e.target.checked)} />
              }
              label={
                <Box className="inner-label">
                  <dl className="item-label">
                    <dt className="title">교통비</dt>
                    <dd>교통비 사용 | ERP001</dd>
                  </dl>
                  <div className="bookmark-area">
                    <ToggleButton
                      value="button"
                      selected={selected}
                      onChange={() => {
                        setSelected(!selected);
                      }}
                      className="btn-icon-toggle icon-bookmark"
                    >
                      <StarRateRoundedIcon fontSize="medium" />
                    </ToggleButton>
                  </div>
                </Box>
              }
            />
          </FormGroup>
        </FormControl>
      </div>
    </>
  );
};

export default ChooseUseCheckbox;
