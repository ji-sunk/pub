import { AppBar, Box, Button, Typography } from "@mui/material";
import { ArrowNarrowLeft } from "@untitled-ui/icons-react";
import { ReactNode } from "react";
import AllMenuDrawer from "src/components/common/AllMenuDrawer";

interface HeaderSubProps {
  children?: ReactNode;
}

const HeaderSub = (props: HeaderSubProps) => {
  return (
    <>
      <AppBar position="fixed" className="sub-header">
        <Box className="inner">
          <div className="left-area">
            <Button
              size="medium"
              className="btn-text-primary"
              startIcon={
                <ArrowNarrowLeft fontSize="medium" className="bp-icon medium" />
              }
            ></Button>
            {/* [D]logo 메인header */}
          </div>
          {/* 비플페이 look과 비슷하게 title위치를 center로 변경 */}
          <div className="center-area">
            <Typography variant="h2" className="bp-title">
              서브타이틀(h2)
            </Typography>
          </div>
          <Box className="right-area">
            {/* [D]개발시 분기처리 */}
            {/* <IconButton
              className="btn-icon-only"
              size="small"
              aria-label="설정"
            >
              <Settings02 fontSize="small" className="bp-icon" />
            </IconButton>
            <IconButton
              className="btn-icon-only"
              size="medium"
              aria-label="검색"
            >
              <SearchSm fontSize="medium" />
            </IconButton>
            <IconButton
              className="btn-icon-only"
              size="medium"
              aria-label="결재"
            >
              <ApprovalOutlinedIcon fontSize="medium" />
            </IconButton>
             */}
            <AllMenuDrawer />
          </Box>
        </Box>
      </AppBar>
    </>
  );
};

export default HeaderSub;
