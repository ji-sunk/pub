import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/effect-cards";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Autoplay, Navigation, Pagination, Scrollbar } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

// let slideInx = 0;
const FractionSwiper = () => {
  SwiperCore.use([Navigation, Scrollbar, Autoplay, Pagination]);
  return (
    <>
      <div className="swiper-container">
        <Swiper
          loop={true} // 슬라이드 루프
          centeredSlides={true}
          spaceBetween={8} // 슬라이스 사이 간격
          slidesPerView={1.2} // 보여질 슬라이스 수
          navigation={false} // prev, next button
          grabCursor={true}
          // initialSlide={slideInx}
          pagination={{
            el: ".swiper-pagination",
            type: "fraction",
            formatFractionCurrent: function (number) {
              return "" + number;
            },
          }}
          // autoplay={{
          //   delay: 2500,
          //   disableOnInteraction: false, // 사용자 상호작용시 슬라이더 일시 정지 비활성
          // }}
          // autoplay={false}
        >
          <SwiperSlide>
            <div>1</div>
          </SwiperSlide>
          <SwiperSlide>
            <div>2</div>
          </SwiperSlide>
          <SwiperSlide>
            <div>3</div>
          </SwiperSlide>
          <SwiperSlide>
            <div>4</div>
          </SwiperSlide>
          <SwiperSlide>
            <div>5</div>
          </SwiperSlide>
        </Swiper>
      </div>
      <div className="pagination-box">
        <div className="swiper-pagination"></div>
      </div>
    </>
  );
};

export default FractionSwiper;
