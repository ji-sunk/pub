import { ChevronRight } from "@mui/icons-material";
import { Box, Card, CardContent } from "@mui/material";
import { ReactNode } from "react";
import { Link } from "react-router-dom";

interface NotiCardProps {
  children?: ReactNode;
}

const NotiCard = (props: NotiCardProps) => (
  <>
    <Card className="card-wrap card-noti">
      <CardContent className="card-cont">
        <Link to="#" className="flex-row">
          <div className="txt bp-ellipsis">
            현대자동차 국내출장플랫폼이 오픈되었습니다. 현대자동차
            국내출장플랫폼이 오픈되었습니다.
          </div>
          <Box className="right-area">
            <ChevronRight className="bp-icon" />
          </Box>
        </Link>
      </CardContent>
    </Card>
  </>
);

export default NotiCard;
