import createCache from "@emotion/cache";
import { CacheProvider } from "@emotion/react";
import { CssBaseline } from "@mui/material";
import { ThemeProvider } from "@mui/material/styles";
import { LicenseInfo } from "@mui/x-data-grid-pro";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { useEffect } from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { RecoilRoot } from "recoil";
import PageRoutes from "./Routes";
import { createTheme } from "./theme";

LicenseInfo.setLicenseKey(
  "e06b87c6ea7811e8568ea0ff3b9a39d3Tz03NjExOCxFPTE3MjgyMDEwMjAwMDAsUz1wcmVtaXVtLExNPXBlcnBldHVhbCxLVj0y",
);

const clientSideEmotionCache = createCache({ key: "css" });

const App = () => {
  const theme = createTheme();

  useEffect(() => {
    const userAgent = navigator.userAgent || navigator.vendor;

    if (/android/i.test(userAgent)) {
      document.body.classList.add("android");
    } else if (/iPad|iPhone|iPod/.test(userAgent)) {
      document.body.classList.add("ios");
    } else {
      document.body.classList.add("nomobile");
    }
  }, []);

  return (
    <CacheProvider value={clientSideEmotionCache}>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <RecoilRoot>
          <ThemeProvider theme={theme}>
            <CssBaseline />
            <Router>
              <PageRoutes />
              {/* <Routes>
                <Route path="/" element={<Navigate to="/main/home" />} />
                <Route path="/auth/MLG000000" element={<MLG000000 />} />
              </Routes> */}
            </Router>
          </ThemeProvider>
        </RecoilRoot>
      </LocalizationProvider>
    </CacheProvider>
  );
};

export default App;
