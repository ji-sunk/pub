
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import MdoMdo010000 from './pages/accounts/mdo/MDO010000.tsx';
import MdoMdo010100 from './pages/accounts/mdo/MDO010100.tsx';
import MdoMdo010200 from './pages/accounts/mdo/MDO010200.tsx';
import MdoMdo010101 from './pages/accounts/mdo/MDO010101.tsx';
import MdoMdo010300 from './pages/accounts/mdo/MDO010300.tsx';
import MdoMdo010400 from './pages/accounts/mdo/MDO010400.tsx';
import MdoMdo010402 from './pages/accounts/mdo/MDO010402.tsx';
import MdoMdo010500 from './pages/accounts/mdo/MDO010500.tsx';
import MdoMdo010501 from './pages/accounts/mdo/MDO010501.tsx';
import MdoMdo010502 from './pages/accounts/mdo/MDO010502.tsx';
import MapMap010000 from './pages/approval/map/MAP010000.tsx';
import MapMap010101 from './pages/approval/map/MAP010101.tsx';
import AuthMlg000000 from './pages/auth/MLG000000.tsx';
import AuthMlg010000 from './pages/auth/MLG010000.tsx';
import AuthMlg010100 from './pages/auth/MLG010100.tsx';
import AuthMlg020000 from './pages/auth/MLG020000.tsx';
import TermsMlg010101 from './pages/auth/terms/MLG010101.tsx';
import TermsMlg010102 from './pages/auth/terms/MLG010102.tsx';
import TermsMlg010103 from './pages/auth/terms/MLG010103.tsx';
import TermsMlg020100 from './pages/auth/terms/MLG020100.tsx';
import TermsMlg020100_bak from './pages/auth/terms/MLG020100_bak.tsx';
import TermsMlg020101 from './pages/auth/terms/MLG020101.tsx';
import TermsMlg020103 from './pages/auth/terms/MLG020103.tsx';
import MbnMbn010000 from './pages/bztrip/mbn/MBN010000.tsx';
import MbnMbn010000_old from './pages/bztrip/mbn/MBN010000_old.tsx';
import MbnMbn010100 from './pages/bztrip/mbn/MBN010100.tsx';
import MbnMbn010100_bak from './pages/bztrip/mbn/MBN010100_bak.tsx';
import MbnMbn010200 from './pages/bztrip/mbn/MBN010200.tsx';
import MbnMbn010300 from './pages/bztrip/mbn/MBN010300.tsx';
import MbnMbn010400 from './pages/bztrip/mbn/MBN010400.tsx';
import MbnMbn010500 from './pages/bztrip/mbn/MBN010500.tsx';
import MbnMbn010501 from './pages/bztrip/mbn/MBN010501.tsx';
import MbnMbn010600 from './pages/bztrip/mbn/MBN010600.tsx';
import MbnMbn020000 from './pages/bztrip/mbn/MBN020000.tsx';
import MbnMbn020000_bak from './pages/bztrip/mbn/MBN020000_bak.tsx';
import MbnMbn020000_old from './pages/bztrip/mbn/MBN020000_old.tsx';
import MdfMdf010000 from './pages/bztrip/mdf/MDF010000.tsx';
import MdfMdf010101 from './pages/bztrip/mdf/MDF010101.tsx';
import MmmMmm010000 from './pages/bztrip/mmm/MMM010000.tsx';
import MmmMmm020000 from './pages/bztrip/mmm/MMM020000.tsx';
import MmmMmm040000 from './pages/bztrip/mmm/MMM040000.tsx';
import MmmMmm050000 from './pages/bztrip/mmm/MMM050000.tsx';
import GuideIndex from './pages/guide/index.tsx';
import GuidePath from './pages/guide/path.tsx';
import PagesIndex from './pages/index.tsx';
import MmaMma000000 from './pages/main/mma/MMA000000.tsx';
import MmaMma000001 from './pages/main/mma/MMA000001.tsx';
import MmaMma010000 from './pages/main/mma/MMA010000.tsx';
import MmaMma010100 from './pages/main/mma/MMA010100.tsx';
import MmaMma010200 from './pages/main/mma/MMA010200.tsx';
import MmaMma010201 from './pages/main/mma/MMA010201.tsx';
import MmaMma010300 from './pages/main/mma/MMA010300.tsx';
import MmaMma010400 from './pages/main/mma/MMA010400.tsx';
import MmaMma010500 from './pages/main/mma/MMA010500.tsx';
import MmaMma010601 from './pages/main/mma/MMA010601.tsx';
import MmaMma010602 from './pages/main/mma/MMA010602.tsx';
import MmaMma010603 from './pages/main/mma/MMA010603.tsx';
import MocMoc010000 from './pages/my/moc/MOC010000.tsx';
import MocMoc020100 from './pages/my/moc/MOC020100.tsx';
import BoardMno000000 from './pages/my/board/MNO000000.tsx';
import BoardMno010000 from './pages/my/board/MNO010000.tsx';
import HipassMmy080100 from './pages/my/hipass/MMY080100.tsx';
import HipassMmy080200 from './pages/my/hipass/MMY080200.tsx';
import HipassMmy080400 from './pages/my/hipass/MMY080400.tsx';
import MmyMmy000000 from './pages/my/mmy/MMY000000.tsx';
import MmyMmy010000 from './pages/my/mmy/MMY010000.tsx';
import MmyMmy020000 from './pages/my/mmy/MMY020000.tsx';
import MPU010000 from './pages/my/msi/MPU010000.tsx';
import MsiMsi010000 from './pages/my/msi/MSI010000.tsx';
import MsiMsi030000 from './pages/my/msi/MSI030000.tsx';
import MsiMsi030100 from './pages/my/msi/MSI030100.tsx';
import MsiMsi030200 from './pages/my/msi/MSI030200.tsx';
import MsiMsi030300 from './pages/my/msi/MSI030300.tsx';
import MycardMcd000000 from './pages/mycard/MCD000000.tsx';
import MycardMcd010000 from './pages/mycard/MCD010000.tsx';
import MtpMtp010000 from './pages/tmpstorage/mtp/MTP010000.tsx';
import ViewsApprovalstep from './pages/views/approvalstep.tsx';
import ViewsBtmdrawer from './pages/views/btmdrawer.tsx';
import ViewsDialoglayer from './pages/views/dialoglayer.tsx';
import ViewsFilterdrawer from './pages/views/filterdrawer.tsx';
import ViewsHeader from './pages/views/Header.tsx';
import ViewsIntrob from './pages/views/introb.tsx';
import ViewsListdrawer from './pages/views/listdrawer.tsx';
import ViewsListdrawerPay from './pages/views/listdrawer_pay.tsx';
import ViewsPaper from './pages/views/paper.tsx';
import ViewsPopup from './pages/views/popup.tsx';
import ViewsSample from './pages/views/sample.tsx';
import ViewsSample2 from './pages/views/sample2.tsx';
import ViewsSignpop from './pages/views/signpop.tsx';
import ViewsTest from './pages/views/test.tsx';
import ViewsZ001a from './pages/views/Z001a.tsx';
import ViewsZ001b from './pages/views/Z001b.tsx';
import ViewsZ002b from './pages/views/Z002b.tsx';

const PageRoutes = () => (
  <Routes>
    <Route path="/accounts/mdo/MDO010000" element={<MdoMdo010000 />} />
<Route path="/accounts/mdo/MDO010100" element={<MdoMdo010100 />} />
<Route path="/accounts/mdo/MDO010200" element={<MdoMdo010200 />} />
<Route path="/accounts/mdo/MDO010101" element={<MdoMdo010101 />} />
<Route path="/accounts/mdo/MDO010300" element={<MdoMdo010300 />} />
<Route path="/accounts/mdo/MDO010400" element={<MdoMdo010400 />} />
<Route path="/accounts/mdo/MDO010402" element={<MdoMdo010402 />} />
<Route path="/accounts/mdo/MDO010500" element={<MdoMdo010500 />} />
<Route path="/accounts/mdo/MDO010501" element={<MdoMdo010501 />} />
<Route path="/accounts/mdo/MDO010502" element={<MdoMdo010502 />} />
<Route path="/approval/map/MAP010000" element={<MapMap010000 />} />
<Route path="/approval/map/MAP010101" element={<MapMap010101 />} />
<Route path="/auth/MLG000000" element={<AuthMlg000000 />} />
<Route path="/auth/MLG010000" element={<AuthMlg010000 />} />
<Route path="/auth/MLG010100" element={<AuthMlg010100 />} />
<Route path="/auth/MLG020000" element={<AuthMlg020000 />} />
<Route path="/auth/terms/MLG010101" element={<TermsMlg010101 />} />
<Route path="/auth/terms/MLG010102" element={<TermsMlg010102 />} />
<Route path="/auth/terms/MLG010103" element={<TermsMlg010103 />} />
<Route path="/auth/terms/MLG020100" element={<TermsMlg020100 />} />
<Route path="/auth/terms/MLG020100_bak" element={<TermsMlg020100_bak />} />
<Route path="/auth/terms/MLG020101" element={<TermsMlg020101 />} />
<Route path="/auth/terms/MLG020103" element={<TermsMlg020103 />} />
<Route path="/bztrip/mbn/MBN010000" element={<MbnMbn010000 />} />
<Route path="/bztrip/mbn/MBN010000_old" element={<MbnMbn010000_old />} />
<Route path="/bztrip/mbn/MBN010100" element={<MbnMbn010100 />} />
<Route path="/bztrip/mbn/MBN010100_bak" element={<MbnMbn010100_bak />} />
<Route path="/bztrip/mbn/MBN010200" element={<MbnMbn010200 />} />
<Route path="/bztrip/mbn/MBN010300" element={<MbnMbn010300 />} />
<Route path="/bztrip/mbn/MBN010400" element={<MbnMbn010400 />} />
<Route path="/bztrip/mbn/MBN010500" element={<MbnMbn010500 />} />
<Route path="/bztrip/mbn/MBN010501" element={<MbnMbn010501 />} />
<Route path="/bztrip/mbn/MBN010600" element={<MbnMbn010600 />} />
<Route path="/bztrip/mbn/MBN020000" element={<MbnMbn020000 />} />
<Route path="/bztrip/mbn/MBN020000_bak" element={<MbnMbn020000_bak />} />
<Route path="/bztrip/mbn/MBN020000_old" element={<MbnMbn020000_old />} />
<Route path="/bztrip/mdf/MDF010000" element={<MdfMdf010000 />} />
<Route path="/bztrip/mdf/MDF010101" element={<MdfMdf010101 />} />
<Route path="/bztrip/mmm/MMM010000" element={<MmmMmm010000 />} />
<Route path="/bztrip/mmm/MMM020000" element={<MmmMmm020000 />} />
<Route path="/bztrip/mmm/MMM040000" element={<MmmMmm040000 />} />
<Route path="/bztrip/mmm/MMM050000" element={<MmmMmm050000 />} />

<Route path="/guide" element={<GuideIndex />} />
<Route path="/guide/path" element={<GuidePath />} />
<Route path="/" element={<PagesIndex />} />
<Route path="/main/mma/MMA000000" element={<MmaMma000000 />} />
<Route path="/main/mma/MMA000001" element={<MmaMma000001 />} />
<Route path="/main/mma/MMA010000" element={<MmaMma010000 />} />
<Route path="/main/mma/MMA010100" element={<MmaMma010100 />} />
<Route path="/main/mma/MMA010200" element={<MmaMma010200 />} />
<Route path="/main/mma/MMA010201" element={<MmaMma010201 />} />
<Route path="/main/mma/MMA010300" element={<MmaMma010300 />} />
<Route path="/main/mma/MMA010400" element={<MmaMma010400 />} />
<Route path="/main/mma/MMA010500" element={<MmaMma010500 />} />
<Route path="/main/mma/MMA010601" element={<MmaMma010601 />} />
<Route path="/main/mma/MMA010602" element={<MmaMma010602 />} />
<Route path="/main/mma/MMA010603" element={<MmaMma010603 />} />
<Route path="/my/board/MNO000000" element={<BoardMno000000 />} />
<Route path="/my/board/MNO010000" element={<BoardMno010000 />} />
<Route path="/my/hipass/MMY080100" element={<HipassMmy080100 />} />
<Route path="/my/hipass/MMY080200" element={<HipassMmy080200 />} />
<Route path="/my/hipass/MMY080400" element={<HipassMmy080400 />} />
<Route path="/my/mmy/MMY000000" element={<MmyMmy000000 />} />
<Route path="/my/mmy/MMY010000" element={<MmyMmy010000 />} />
<Route path="/my/mmy/MMY020000" element={<MmyMmy020000 />} />

<Route path="/my/moc/MOC010000" element={<MocMoc010000 />} />
<Route path="/my/moc/MOC020100" element={<MocMoc020100 />} />
<Route path="/my/msi/MPU010000" element={<MPU010000 />} />
<Route path="/my/msi/MSI010000" element={<MsiMsi010000 />} />
<Route path="/my/msi/MSI030000" element={<MsiMsi030000 />} />
<Route path="/my/msi/MSI030100" element={<MsiMsi030100 />} />
<Route path="/my/msi/MSI030200" element={<MsiMsi030200 />} />
<Route path="/my/msi/MSI030300" element={<MsiMsi030300 />} />
<Route path="/mycard/MCD000000" element={<MycardMcd000000 />} />
<Route path="/mycard/MCD010000" element={<MycardMcd010000 />} />
<Route path="/tmpstorage/mtp/MTP010000" element={<MtpMtp010000 />} />
<Route path="/views/approvalstep" element={<ViewsApprovalstep />} />
<Route path="/views/btmdrawer" element={<ViewsBtmdrawer />} />
<Route path="/views/dialoglayer" element={<ViewsDialoglayer />} />
<Route path="/views/filterdrawer" element={<ViewsFilterdrawer />} />
<Route path="/views/Header" element={<ViewsHeader />} />
<Route path="/views/introb" element={<ViewsIntrob />} />
<Route path="/views/listdrawer" element={<ViewsListdrawer />} />
<Route path="/views/listdrawer_pay" element={<ViewsListdrawerPay />} />
<Route path="/views/paper" element={<ViewsPaper />} />
<Route path="/views/popup" element={<ViewsPopup />} />
<Route path="/views/sample" element={<ViewsSample />} />
<Route path="/views/sample2" element={<ViewsSample2 />} />
<Route path="/views/signpop" element={<ViewsSignpop />} />
<Route path="/views/test" element={<ViewsTest />} />
<Route path="/views/Z001a" element={<ViewsZ001a />} />
<Route path="/views/Z001b" element={<ViewsZ001b />} />
<Route path="/views/Z002b" element={<ViewsZ002b />} />
  </Routes>
);

export default PageRoutes;
