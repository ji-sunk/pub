import { Box, Tab, Tabs } from "@mui/material";
import * as React from "react";
import { useState } from "react";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  tabValue: number;
}

function BasicTabPanel(props: TabPanelProps) {
  const { children, tabValue, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={tabValue !== index}
      id={`basic-tabpanel-${index}`}
      aria-labelledby={`basic-tab-${index}`}
      {...other}
      className="tab-panel"
    >
      {tabValue === index && <div className="panel-inner">{children}</div>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `basic-tab-${index}`,
    "aria-controls": `basic-tabpanel-${index}`,
  };
}

const BpTabs = (props) => {
  const [tabValue, setTabValue] = React.useState(0);

  const tabHandleChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  // 상위 컴포넌트에서 하위 탭 데이터와 각 탭에 대한 상태 및 상태 변경 함수 초기화
  const [subTabs, setSubTabs] = useState([
    { label: "법인카드" },
    { label: "법인카드(전체)" },
    { label: "개인카드" },
    { label: "개인카드(전체)" },
  ]);

  // 하위 탭 데이터와 각 탭에 대한 상태 및 상태 변경 함수 초기화
  const [subTabStates, setSubTabStates] = useState(
    subTabs.map(() => ({ tabValue: 0 })),
  );

  // 각 하위 탭의 탭 변경 핸들러 함수
  const handleTabChange = (index: number, newValue: number) => {
    setSubTabStates((prevStates) => {
      const newSubTabStates = [...prevStates];
      newSubTabStates[index].tabValue = newValue;
      return newSubTabStates;
    });
  };

  return (
    <>
      <Box className="bp-tabs tabs-basic tabs-size-medium tabs-layout-type">
        <Tabs
          className="tab-list tab-typeLine"
          value={tabValue}
          onChange={tabHandleChange}
          aria-label=""
        >
          <Tab label="텝1" {...a11yProps(0)} />
          <Tab label="텝2-서브텝 샘플" {...a11yProps(1)} />
          <Tab label="사용자별 권한부여" {...a11yProps(3)} />
          <Tab label="권한그룹별 권한부여" {...a11yProps(4)} />
        </Tabs>
        <BasicTabPanel tabValue={tabValue} index={0}>
          전체
        </BasicTabPanel>
        <BasicTabPanel tabValue={tabValue} index={1}>
          <div className="ui-module">
            <Box className="bp-tbl-card-group">
              <Box className="bp-tabs tabs-basic tabs-size-medium tabs-sub">
                {/* 하위 텝 */}
                {subTabs.map((subTab, index) => (
                  <BasicTabPanel key={index} tabValue={tabValue} index={index}>
                    <Tabs
                      value={subTabStates[index].tabValue}
                      onChange={(event, newValue) =>
                        handleTabChange(index, newValue)
                      }
                      aria-label="상단텝명-서브텝명"
                      className="tab-list tab-typeLine"
                    >
                      {subTabs.map((subTab, tabIndex) => (
                        <Tab
                          key={tabIndex}
                          label={subTab.label}
                          {...a11yProps(tabIndex)}
                        />
                      ))}
                    </Tabs>
                    <BasicTabPanel
                      tabValue={subTabStates[index].tabValue}
                      index={0}
                    >
                      서브텝 샘플
                    </BasicTabPanel>
                    <BasicTabPanel
                      tabValue={subTabStates[index].tabValue}
                      index={1}
                    >
                      법인카드(전체)
                    </BasicTabPanel>
                    <BasicTabPanel
                      tabValue={subTabStates[index].tabValue}
                      index={2}
                    >
                      개인카드
                    </BasicTabPanel>
                    <BasicTabPanel
                      tabValue={subTabStates[index].tabValue}
                      index={3}
                    >
                      개인카드(전체)
                    </BasicTabPanel>
                  </BasicTabPanel>
                ))}
              </Box>
            </Box>
          </div>
        </BasicTabPanel>
        <BasicTabPanel tabValue={tabValue} index={2}>
          결의진행
        </BasicTabPanel>
      </Box>
    </>
  );
};

export default BpTabs;
