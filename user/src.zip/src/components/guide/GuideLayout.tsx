import { Box, Container } from "@mui/material";
import { FC, ReactNode } from "react";
import styles from "./Guide.module.css";
import Header from "./Header";

type GuideLayoutProps = {
  children: ReactNode;
};

const GuideLayout: FC<GuideLayoutProps> = (props) => {
  const { children } = props;

  return (
    <Container className={styles.container}>
      <Header />
      {/* <BzpAlert /> */}
      <Box component="main" className={styles.main}>
        {children}
      </Box>
    </Container>
  );
};

export default GuideLayout;
