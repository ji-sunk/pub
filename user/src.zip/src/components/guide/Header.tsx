import { ReactNode } from "react";

import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import { Link } from "react-router-dom";
import styles from "./Guide.module.css";

interface GuideHeaderProps {
  children?: ReactNode;
}

const navLinks = [
  { id: 1, name: "가이드", url: "/guide" },
  { id: 2, name: "작업 파일 경로", url: "/guide/path" },
];

const GuideHeader = (props: GuideHeaderProps) => (
  <>
    <header className={styles.gnbheader}>
      <h1 className={styles.gnbtitle}>BP Mobile HYUNDAI Guide</h1>
      <nav className={styles.gnbNav}>
        <List className={styles.gnbMenu}>
          {navLinks.map((item) => (
            <ListItem key={item.id} disablePadding>
              <Link to={item.url} target="_blank">
                {item.name}
              </Link>
            </ListItem>
          ))}
        </List>
      </nav>
    </header>
  </>
);

export default GuideHeader;
