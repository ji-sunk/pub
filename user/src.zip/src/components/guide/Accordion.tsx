import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  IconButton,
  Stack,
  Switch,
} from "@mui/material";
import { ChevronDown, Plus } from "@untitled-ui/icons-react";
import * as React from "react";
import styles from "./Guide.module.css";

const BpAccordion = (props) => {
  const label = { inputProps: { "aria-label": "Switch demo" } };
  // 아코디언 Multi
  const [expandedMulti, setExpandedMulti] = React.useState(false);
  const handleExpansionMulti = () => {
    setExpandedMulti((prevExpanded) => !prevExpanded);
  };
  // 아코디언 Single
  const [expandedSingle, setExpandedSingle] = React.useState<string | false>(
    "panel2-1",
  );
  const handleExpansionSingle =
    (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
      setExpandedSingle(newExpanded ? panel : false);
    };

  return (
    <>
      <h3 className={styles.heading3}>9-1. [공통]기본 타입(Multi 열림)</h3>
      <div className="bp-accordion accordion-basic">
        <Accordion
          disableGutters
          elevation={0}
          defaultExpanded
          expanded={expandedMulti}
          onChange={handleExpansionMulti}
        >
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            className="acc-header"
            expandIcon={
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="열기/닫기"
              >
                <ChevronDown fontSize="small" className="bp-icon small" />
              </IconButton>
            }
          >
            <div className="acc-inner">
              <Box className="left">
                <Stack spacing={0} className="acc-group-title">
                  <Stack spacing={0} className="acc-title">
                    결의조건
                  </Stack>
                  <Stack spacing={0} className="acc-description">
                    부서, 신청금액, 날짜/시간, 사용자
                  </Stack>
                </Stack>
              </Box>
              <Box className="right"></Box>
            </div>
          </AccordionSummary>
          <AccordionDetails className="acc-body">
            <div className="acc-inner">내용-기본 타입1</div>
          </AccordionDetails>
        </Accordion>
        <Accordion disableGutters elevation={0}>
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            className="acc-header"
            expandIcon={
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="열기/닫기"
              >
                <ChevronDown fontSize="small" className="bp-icon small" />
              </IconButton>
            }
          >
            <div className="acc-inner">
              <Box className="left">
                <Stack spacing={0} className="acc-group-title">
                  <Stack spacing={0} className="acc-title">
                    지정결재자
                    <div className="acc-title-side">
                      <Button
                        variant="outlined"
                        size="medium"
                        className=""
                        startIcon={
                          <Plus fontSize="small" className="bp-icon small" />
                        }
                        onClick={(e) => e.stopPropagation()}
                      >
                        결재자 추가
                      </Button>
                    </div>
                  </Stack>
                  <Stack spacing={0} className="acc-description">
                    부서, 신청금액, 날짜/시간, 사용자
                  </Stack>
                </Stack>
              </Box>
              <Box className="right"></Box>
            </div>
          </AccordionSummary>
          <AccordionDetails className="acc-body">
            <div className="acc-inner">내용-기본 타입2</div>
          </AccordionDetails>
        </Accordion>
      </div>
      <h3 className={styles.heading3}>
        9-2. [공통]좌우 reverse 타입(Single 열림)
      </h3>
      <div className="bp-accordion accordion-arrow-reverse">
        <Accordion
          disableGutters
          elevation={0}
          expanded={expandedSingle === "panel2-1"}
          onChange={handleExpansionSingle("panel2-1")}
        >
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            className="acc-header"
            onClick={() =>
              setExpandedSingle(
                expandedSingle === "panel2-1" ? false : "panel2-1",
              )
            }
            expandIcon={
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="열기/닫기"
              >
                <ChevronDown fontSize="small" className="bp-icon small" />
              </IconButton>
            }
          >
            <div className="acc-inner">
              <Box className="left">
                <Stack spacing={0} className="acc-group-title">
                  <Stack spacing={0} className="acc-title">
                    입력항목 설정
                  </Stack>
                  <Stack spacing={0} className="acc-description">
                    부서, 신청금액, 날짜/시간, 사용자
                  </Stack>
                </Stack>
              </Box>
              <Box className="right">
                <Switch
                  {...label}
                  defaultChecked
                  onClick={(e) => e.stopPropagation()}
                />
              </Box>
            </div>
          </AccordionSummary>
          <AccordionDetails className="acc-body">
            <div className="acc-inner">내용</div>
          </AccordionDetails>
        </Accordion>
        <Accordion
          disableGutters
          elevation={0}
          expanded={expandedSingle === "panel2-2"}
          onChange={handleExpansionSingle("panel2-2")}
        >
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            className="acc-header"
            onClick={() =>
              setExpandedSingle(
                expandedSingle === "panel2-2" ? false : "panel2-2",
              )
            }
            expandIcon={
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="열기/닫기"
              >
                <ChevronDown fontSize="small" className="bp-icon small" />
              </IconButton>
            }
          >
            <div className="acc-inner">
              <Box className="left">
                <Stack spacing={0} className="acc-group-title">
                  <Stack spacing={0} className="acc-title">
                    사진 필수 첨부 설정 (사용내역 작성 시)
                  </Stack>
                  <Stack spacing={0} className="acc-description">
                    법인카드, 기타증빙, 계산서
                  </Stack>
                </Stack>
              </Box>
              <Box className="right">
                <Switch
                  {...label}
                  defaultChecked
                  onClick={(e) => e.stopPropagation()}
                />
              </Box>
            </div>
          </AccordionSummary>
          <AccordionDetails className="acc-body">
            <div className="acc-inner">내용</div>
          </AccordionDetails>
        </Accordion>
      </div>
    </>
  );
};

export default BpAccordion;
