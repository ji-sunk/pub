import { InputAdornment } from "@mui/material";
import { MobileDatePicker } from "@mui/x-date-pickers";
import { Calendar } from "@untitled-ui/icons-react";

const PeriodCalendar = () => {
  return (
    <>
      <div className="item-field period-calendar">
        <div className="item">
          <MobileDatePicker
            label="시작일"
            className="bp-datePicker fullWidth"
            format="yyyy/MM/dd"
            slotProps={{
              textField: {
                // helperText: "YYYY/MM/DD",
                InputProps: {
                  endAdornment: (
                    <InputAdornment position="end" className="icon-area">
                      <Calendar className="bp-icon" />
                    </InputAdornment>
                  ),
                },
              },
            }}
          />
        </div>
        <div className="tilde-symbol">~</div>
        <div className="item">
          <MobileDatePicker
            label="종료일"
            className="bp-datePicker fullWidth"
            format="yyyy/MM/dd"
            slotProps={{
              textField: {
                // helperText: "YYYY/MM/DD",
                InputProps: {
                  endAdornment: (
                    <InputAdornment position="end" className="icon-area">
                      <Calendar className="bp-icon" />
                    </InputAdornment>
                  ),
                },
              },
            }}
          />
        </div>
      </div>
    </>
  );
};
export default PeriodCalendar;
