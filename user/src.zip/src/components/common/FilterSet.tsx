import { Chip, IconButton } from "@mui/material";
import { Settings04 } from "@untitled-ui/icons-react";
import { FC } from "react";

type FilterSetProps = {};
const FilterSet: FC<FilterSetProps> = () => {
  return (
    <>
      <div className="filter-set">
        <div className="inner-sides">
          <div className="left-area">
            <div className="txt">
              총 <span className="txt-cases">2건</span>
            </div>
          </div>
          <div className="right-area">
            <div className="chips-group">
              <Chip
                label="전체"
                size="medium"
                variant="outlined"
                className="bp-chip color-neutral"
                color="default"
              />
              <Chip
                label="1주일"
                size="medium"
                variant="outlined"
                className="bp-chip color-neutral"
                color="default"
              />
              {/* <Chip
                    label="1개월"
                    size="medium"
                    variant="outlined"
                    className="bp-chip"
                    color="default"
                  />
                  <Chip
                    label="3주일"
                    size="medium"
                    variant="outlined"
                    className="bp-chip"
                    color="default"
                  />
                  <Chip
                    label="2024.05.01~2024.05.30"
                    size="medium"
                    variant="outlined"
                    className="bp-chip"
                    color="default"
                  /> */}
            </div>
            <div className="btns-group">
              <IconButton className="btn-icon-only" size="small">
                <Settings04
                  fontSize="medium"
                  className="bp-icon color-secondary"
                />
              </IconButton>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FilterSet;
