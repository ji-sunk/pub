import { Avatar, Button, IconButton, Paper, Typography } from "@mui/material";
import { Edit02 } from "@untitled-ui/icons-react";
import { useRef } from "react";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";

const MMY020000 = () => {
  // 버튼 file
  const fileInputRef1 = useRef(null);
  const handleButtonClick1 = () => {
    fileInputRef1.current.click();
  };
  const handleFileChange1 = (event) => {
    //
  };
  return (
    <>
      <Head>
        <title>개인정보 수정 | 마이페이지</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper" , mypage-wrap */}
        <Paper className="ui-paper mypage-wrap">
          {/* [E]edit-personal */}
          <div className="edit-personal">
            <div className="light-box">
              <div className="ui-box">
                <dl className="item-user-info">
                  <dt className="photo">
                    <Avatar
                      alt="최현대"
                      src="/assets/images/tmp-profile2.png"
                      className="user-avatar"
                    />
                    <div className="file-edit">
                      <input
                        ref={fileInputRef1}
                        type="file"
                        onChange={handleFileChange1}
                        className="hidden"
                      />
                      <IconButton
                        className="btn-icon-only btn-circle btn-basic"
                        size="small"
                        aria-label="수정"
                        onClick={handleButtonClick1}
                      >
                        <Edit02 fontSize="small" className="bp-icon xsmall" />
                      </IconButton>
                    </div>
                  </dt>
                  <dd>
                    <div className="user-name">최현대 과장(1341341)</div>
                    {/* <div className="user-team">라이프디자인팀 (TBCM-1)</div> */}
                  </dd>
                </dl>
              </div>
            </div>
            <div className="light-box full-height">
              <div className="ui-box">
                <div className="bp-list">
                  <Typography variant="h3">기본정보</Typography>

                  <dl className="item-field">
                    <dt className="txt-title">이름(한글)</dt>
                    <dd className="right-area">
                      <div className="txt-data">김현대</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">이름(영문)</dt>
                    <dd className="right-area">
                      <div className="txt-data">Hyundai KIM</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">아이디</dt>
                    <dd className="right-area">
                      <div className="txt-data">hd_kim</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">비밀번호</dt>
                    <dd className="right-area">
                      <Button
                        size="large"
                        className="btn-text"
                        endIcon={
                          <Edit02 fontSize="small" className="bp-icon small" />
                        }
                      >
                        비밀번호 변경
                      </Button>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">휴대폰번호</dt>
                    <dd className="right-area">
                      <div className="txt-data">010-0000-1111</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">이메일</dt>
                    <dd className="right-area">
                      <div className="txt-data">hdkim@hyundai.com</div>
                    </dd>
                  </dl>
                </div>
              </div>
              <div className="ui-box">
                <div className="bp-list">
                  <Typography variant="h3">소속정보</Typography>

                  <dl className="item-field">
                    <dt className="txt-title">그룹</dt>
                    <dd className="right-area">
                      <div className="txt-data">현대자동차</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">그룹코드</dt>
                    <dd className="right-area">
                      <div className="txt-data">H101</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">회사</dt>
                    <dd className="right-area">
                      <div className="txt-data">현대자동차</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">부서</dt>
                    <dd className="right-area">
                      <div className="txt-data">라이프디자인팀</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">직급</dt>
                    <dd className="right-area">
                      <div className="txt-data">매니저</div>
                    </dd>
                  </dl>
                  <dl className="item-field">
                    <dt className="txt-title">직책</dt>
                    <dd className="right-area">
                      <div className="txt-data">팀장</div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
          {/* [E]edit-personal */}
        </Paper>
        {/* [E]ui-paper mypage-wrap */}
      </LayoutSub>
    </>
  );
};

export default MMY020000;
