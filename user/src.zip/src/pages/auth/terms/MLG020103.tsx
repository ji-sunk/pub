import {
  AppBar,
  Box,
  Button,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";

import Dialog, { DialogProps } from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import { GridCloseIcon } from "@mui/x-data-grid";
import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { Helmet as Head } from "react-helmet";

const MLG020103 = () => {
  const [selected, setSelected] = React.useState(false);
  // [팝업]기본 팝업
  const [openDialog, setOpenDialog] = React.useState(false);
  const [scroll, setScroll] = React.useState<DialogProps["scroll"]>("paper");
  const handleClickOpenDialog = (scrollType: DialogProps["scroll"]) => () => {
    setOpenDialog(true);
    setScroll(scrollType);
  };

  const descriptionElementRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    if (openDialog) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [openDialog]);

  // [팝업]FullPaper
  const [OpenFullPaper, setOpenFullPaper] = React.useState(false);
  const handleClickOpenFullPaper =
    (scrollType: DialogProps["scroll"]) => () => {
      setOpenFullPaper(true);
      setScroll(scrollType);
    };
  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [writeOpen, setWriteOpen] = useState(false);
  const writeAnchorRef = useRef<HTMLButtonElement>(null);

  // return focus to the button when we transitioned from !open -> open
  const prevWriteOpen = useRef(writeOpen);
  useEffect(() => {
    if (prevWriteOpen.current === true && writeOpen === false) {
      writeAnchorRef.current!.focus();
    }
    prevWriteOpen.current = writeOpen;
  }, [writeOpen]);
  return (
    <>
      <Head>
        <title>이벤트 / 프로모션 정보 수신 동의</title>
      </Head>
      {/* [S]개인정보 수집 이용 취급 위탁동의 */}
      <Dialog
        fullScreen
        open
        //   open={OpenFullPaper}
        onClose={handleCloseFullPaper}
        scroll={scroll}
        className="bp-dialog dialog-full-paper"
      >
        <DialogTitle component="div" className="bp-dialog-header">
          {/* [S]<HeaderDialog /> */}
          <AppBar position="fixed" className="sub-header">
            <Box className="inner">
              <div className="center-area">
                <Typography variant="h3">
                  이벤트 / 프로모션 정보 수신 동의
                </Typography>
              </div>
              <div className="right-area">
                <IconButton
                  className="btn-icon-only"
                  size="small"
                  aria-label="닫기"
                  onClick={handleCloseFullPaper}
                >
                  <GridCloseIcon fontSize="small" className="bp-icon" />
                </IconButton>
              </div>
            </Box>
          </AppBar>
          {/* [E]HeaderDialog */}
        </DialogTitle>
        <DialogContent
          dividers={scroll === "paper"}
          className="dialog-body"
          ref={descriptionElementRef}
          tabIndex={-1}
        >
          <div className="ui-inner">
            {/* [S]terms-details */}
            <div className="terms-details">
              <ul>
                <li>
                  <p>이벤트 / 프로모션 정보 수신 동의</p>
                  <div className="style-table-box">
                    <dl className="style-row">
                      <dt>이용목적</dt>
                      <dd>
                        이벤트 / 혜택 등 다양한 정보를 휴대전화 (서비스 앱 알림
                        또는 문자), 이메일로 제공
                      </dd>
                    </dl>
                    <dl className="style-row">
                      <dt>수집항목</dt>
                      <dd>
                        휴대폰번호, <br />
                        이메일주소
                      </dd>
                    </dl>
                    <dl className="style-row">
                      <dt>보유기간</dt>
                      <dd>회원 탈퇴 시 까지</dd>
                    </dl>
                  </div>
                </li>
                <li>
                  * 중요 공지 및 알림 등은 설정에 관계없이 발송됩니다.
                  <br />* 수신동의 여부 및 자세한 설정은 아래 메뉴에서 언제든지
                  변경할 수 있습니다.
                </li>
                <li>
                  <div className="box-indent">
                    PC &gt; 내정보 &gt; 프로필 수정 &gt; 정보 수신동의 <br />
                  </div>
                  <div className="box-indent">
                    MO &gt; 마이페이지 &gt; 알림설정 &gt; 정보 수신동의
                  </div>
                </li>
              </ul>
            </div>
            {/* [E]terms-details */}
          </div>
        </DialogContent>
        <DialogActions className="dialog-footer">
          {/* [S]<BtnsGroup /> */}
          <Box className="btns-group">
            <Box className="inner">
              <Button variant="contained" size="large" className="btn-xlarge">
                {/* 240819 modify */}
                동의하기
              </Button>
            </Box>
          </Box>
          {/* [E]BtnsGroup */}
        </DialogActions>
      </Dialog>
      {/* [E]bizplay이용약관 */}
    </>
  );
};

export default MLG020103;
