import CancelIcon from "@mui/icons-material/Cancel";
import CloseIcon from "@mui/icons-material/Close";
import {
  Button,
  InputAdornment,
  List,
  ListItem,
  AppBar,
  Box,
  Card,
  Chip,
  DialogTitle,
  IconButton,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";
import { GridCloseIcon } from "@mui/x-data-grid";
import { Margin } from "@mui/icons-material";

const selectOption = [
  { label: "일반출장 출장 출장", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

const Header = () => {
  const clearSearch = () => {
    setFilteredLocations("");
  };

  const filterResults = (e) => {
    setFilteredLocations(e.target.value);
  };

  const handleCloseFullPaper = () => {
    setOpenFullPaper(false);
  };

  const [filteredLocations, setFilteredLocations] = useState("");
  const handleDeleteChip = () => {
    console.info("");
  };
  const departmentChipsData = [
    { id: 1, departmentName: "비서실" },
    { id: 2, departmentName: "영업팀" },
  ];
  const departmentChips = departmentChipsData.map((data) => (
    <ListItem key={data.id}>
      <Chip
        variant="outlined"
        label={
          <>
            <span className="department-name">{data.departmentName}</span>
            {/* <span className="employee-number">{data.employeeNumber}</span> */}
          </>
        }
        onDelete={handleDeleteChip}
        deleteIcon={<CloseIcon fontSize="small" className="bp-icon xsmall" />}
        className="bp-chip chip-light"
        size="medium"
      />
    </ListItem>
  ));
  return (
    <>
      <Head>
        <title>[Z002b] 용도 선택_다건</title>
      </Head>
      <LayoutSub>
        dfdfdf
      </LayoutSub>
      <DialogTitle component="div" className="bp-dialog-header">
        {/* [S]<HeaderDialog /> */}
        <AppBar className="sub-header">
          <Box className="inner">
            <div className="center-area">
              <Typography variant="h3">출장정보 상세1</Typography>
            </div>
            <div className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={handleCloseFullPaper}
              >
                <GridCloseIcon fontSize="small" className="bp-icon" />
              </IconButton>
            </div>
          </Box>
        </AppBar>
        {/* [E]HeaderDialog */}
      </DialogTitle>
      <DialogTitle component="div" className="bp-dialog-header mgt-120" >
        {/* [S]<HeaderDialog /> */}
        <AppBar className="sub-header">
          <Box className="inner">
            <div className="center-area">
              <Typography variant="h3">출장정보 상세12344</Typography>
            </div>
            <div className="right-area">
              <IconButton
                className="btn-icon-only"
                size="small"
                aria-label="닫기"
                onClick={handleCloseFullPaper}
              >
                <GridCloseIcon fontSize="small" className="bp-icon" />
              </IconButton>
            </div>
          </Box>
        </AppBar>
        {/* [E]HeaderDialog */}
      </DialogTitle>
    </>
  );
};

export default Header;
