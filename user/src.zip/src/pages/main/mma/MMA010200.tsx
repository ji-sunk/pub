import PlaceIcon from "@mui/icons-material/Place";
import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Paper,
  Tab,
  Tabs,
  TextField,
  IconButton,
  // ArrowLeft,
} from "@mui/material";
import {
  Bell01,
  Globe02,
  ChevronRight,
} from "@untitled-ui/icons-react";
import * as React from "react";
import { useState } from "react";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  tabValue: number;
}

function BasicTabPanel(props: TabPanelProps) {
  const { children, tabValue, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={tabValue !== index}
      id={`basic-tabpanel-${index}`}
      aria-labelledby={`basic-tab-${index}`}
      {...other}
      className="tab-panel"
    >
      {tabValue === index && <div className="panel-inner">{children}</div>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `basic-tab-${index}`,
    "aria-controls": `basic-tabpanel-${index}`,
  };
}

const selectOption = [
  { label: "label1", title: "The Shawshank Redemption" },
  { label: "label2", title: "The Shawshank Redemption" },
  { label: "label3", title: "The Shawshank Redemption" },
  { label: "label4", title: "The Shawshank Redemption" },
  { label: "label5", title: "The Shawshank Redemption" },
  { label: "label6", title: "The Shawshank Redemption" },
];

const MMA010200 = (props) => {
  const [tabValue, setTabValue] = React.useState(0);

  const tabHandleChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  // 상위 컴포넌트에서 하위 탭 데이터와 각 탭에 대한 상태 및 상태 변경 함수 초기화
  const [subTabs, setSubTabs] = useState([
    { label: "전체" },
    { label: "기차" },
    { label: "고속버스" },
    { label: "항공" },
  ]);

  return (
    <>
      <Head>
        <title>교통수단 추천</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper" , flex-wrap */}
        <Paper className="ui-paper flex-wrap">
          {/* [S]map-route-wrap */}
          <div className="map-route-wrap">
            <div className="light-box">
              <div className="ui-box">
                <div className="item-field">
                  <TextField
                    variant="filled"
                    size="medium"
                    label="출발지"
                    placeholder=""
                    className="type-address"
                  />
                </div>
                <div className="item-field">
                  <TextField
                    variant="filled"
                    size="medium"
                    label="목적지"
                    placeholder=""
                    className="type-address"
                  />
                </div>
                {/* [S]BTN 추가 20240925 kjs */}
                <Box className="btns-group two">
                  <Box className="inner">
                    <Button
                      variant="contained"
                      size="large"
                      className="btn-xlarge color-neutral"
                    >
                      구간선택
                    </Button>
                    <Button variant="contained" size="large" className="btn-xlarge">
                      검색하기
                    </Button>
                  </Box>
                </Box>
                {/* [E]BTN 추가 20240925 kjs */}
              </div>
            </div>
            <div className="tabs-box">
              <Box className="bp-tabs tabs-basic tabs-size-medium bp-tabs-top">
                <Tabs
                  className="tab-list tab-typeLine"
                  value={tabValue}
                  onChange={tabHandleChange}
                  TabIndicatorProps={{
                    sx: { backgroundColor: "#00AAD2" },
                  }}
                  aria-label=""
                >
                  <Tab label="전체" {...a11yProps(0)} />
                  <Tab label="기차" {...a11yProps(1)} />
                  <Tab label="고속버스" {...a11yProps(2)} />
                  <Tab label="항공" {...a11yProps(3)} />
                </Tabs>
                <div className="ui-box">
                  <BasicTabPanel tabValue={tabValue} index={0}>
                    <div className="bztrip-list">
                      {/* 항공 */}
                      <Card className="item">
                        <CardContent>
                          {/* [S]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <div className="inner-sides">
                            <div className="title-area left-area">
                              {/* 240819 modify */}
                              <div className="txt">1시간</div>
                              <div className="txt-detail">
                                <div className="txt-desc item-txt">
                                  항공 1시간
                                </div>
                                
                                {/* <Box className="right">
                                  <Button
                                    size="small"
                                    className="btn-text-primary btn-go-back"
                                    startIcon={
                                      <ArrowLeft fontSize="small" className="bp-icon xsmall" />
                                    }
                                  >
                                    뒤로가기
                                  </Button>
                                </Box> */}
                                {/* <div className="type-amount item-txt">
                                  <div className="number-area">
                                    295,000
                                    <span className="txt-currency">원</span>
                                  </div>
                                </div> */}
                              </div>
                            </div>
                            <div className="right-area">
                              <IconButton>
                                <ChevronRight className="bp-icon" />
                              </IconButton>
                            </div>
                          </div>
                          {/* [E]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <Box className="transportation-schedule">
                            <Box className="trip-route-box">
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-error"
                                  aria-label="항공"
                                >
                                  <span className="bp-icon icon-flight"></span>
                                </Avatar>
                              </div>
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-success"
                                  aria-label="거래처"
                                >
                                  <PlaceIcon className="bp-icon xsmall" />
                                </Avatar>
                              </div>
                            </Box>
                          </Box>
                          <div className="item-field">
                            <dl className="flex-row-half">
                              <dt className="left-area">
                                <div className="txt">김포국제공항</div>
                              </dt>
                              <dd className="right-area">
                                <Box className="txt">울산공항</Box>
                              </dd>
                            </dl>
                          </div>
                        </CardContent>
                      </Card>
                      {/* 기차 */}
                      <Card className="item">
                        <CardContent>
                           {/* [S]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                           <div className="inner-sides">
                           <div className="title-area left-area">
                            <div className="txt">2시간 11분</div>
                            <div className="txt-detail">
                              <div className="txt-desc item-txt">
                                보도 15분
                              </div>
                              <div className="txt-desc item-txt">
                                환승 2회
                              </div>
                              <div className="txt-desc item-txt">
                                312.8km
                              </div>
                              {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                            </div>
                          </div>
                            <div className="right-area">
                              <IconButton>
                                <ChevronRight className="bp-icon" />
                              </IconButton>
                            </div>
                          </div>
                          {/* [E]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <Box className="transportation-schedule">
                            <Box className="trip-route-box">
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-error"
                                  aria-label="기차"
                                >
                                  <span className="bp-icon icon-train"></span>
                                </Avatar>
                              </div>
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-success"
                                  aria-label="거래처"
                                >
                                  <PlaceIcon className="bp-icon xsmall" />
                                </Avatar>
                              </div>
                            </Box>
                          </Box>
                          <div className="item-field">
                            <dl className="flex-row-half">
                              <dt className="left-area">
                                <div className="txt">서울역</div>
                              </dt>
                              <dd className="right-area">
                                <Box className="txt">울산(통도사)역</Box>
                              </dd>
                            </dl>
                          </div>
                        </CardContent>
                      </Card>

                      {/* 고속버스 */}
                      <Card className="item">
                        <CardContent>
                          {/* [S]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <div className="inner-sides">
                           <div className="title-area left-area">
                            <div className="txt">3시간 11분</div>
                            <div className="txt-detail">
                              <div className="txt-desc item-txt">
                                보도 13분
                              </div>
                              <div className="txt-desc item-txt">
                                환승 1회
                              </div>
                              <div className="txt-desc item-txt">
                                312.8km
                              </div>
                              {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                            </div>
                          </div>
                            <div className="right-area">
                              <IconButton>
                                <ChevronRight className="bp-icon" />
                              </IconButton>
                            </div>
                          </div>
                          {/* [E]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <Box className="transportation-schedule">
                            <Box className="trip-route-box">
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-error"
                                  aria-label="고속버스"
                                >
                                  <span className="bp-icon icon-bus"></span>
                                </Avatar>
                              </div>
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-success"
                                  aria-label="거래처"
                                >
                                  <PlaceIcon className="bp-icon xsmall" />
                                </Avatar>
                              </div>
                            </Box>
                          </Box>
                          <div className="item-field">
                            <dl className="flex-row-half">
                              <dt className="left-area">
                                <div className="txt">
                                  출발지명이 길어지면 하단으로 2줄처리
                                </div>
                              </dt>
                              <dd className="right-area">
                                <Box className="txt">
                                  도착지명이 길어지면 하단으로 2줄처리
                                </Box>
                              </dd>
                            </dl>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </BasicTabPanel>
                  <BasicTabPanel tabValue={tabValue} index={1}>
                    <div className="bztrip-list">
                     {/* 기차 */}
                     <Card className="item">
                        <CardContent>
                           {/* [S]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                           <div className="inner-sides">
                           <div className="title-area left-area">
                            <div className="txt">2시간 11분</div>
                            <div className="txt-detail">
                              <div className="txt-desc item-txt">
                                보도 15분
                              </div>
                              <div className="txt-desc item-txt">
                                환승 2회
                              </div>
                              <div className="txt-desc item-txt">
                                312.8km
                              </div>
                              {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                            </div>
                          </div>
                            <div className="right-area">
                              <IconButton>
                                <ChevronRight className="bp-icon" />
                              </IconButton>
                            </div>
                          </div>
                          {/* [E]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <Box className="transportation-schedule">
                            <Box className="trip-route-box">
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-error"
                                  aria-label="기차"
                                >
                                  <span className="bp-icon icon-train"></span>
                                </Avatar>
                              </div>
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-success"
                                  aria-label="거래처"
                                >
                                  <PlaceIcon className="bp-icon xsmall" />
                                </Avatar>
                              </div>
                            </Box>
                          </Box>
                          <div className="item-field">
                            <dl className="flex-row-half">
                              <dt className="left-area">
                                <div className="txt">서울역</div>
                              </dt>
                              <dd className="right-area">
                                <Box className="txt">울산(통도사)역</Box>
                              </dd>
                            </dl>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </BasicTabPanel>
                  <BasicTabPanel tabValue={tabValue} index={2}>
                    <div className="bztrip-list">
                       {/* 고속버스 */}
                       <Card className="item">
                        <CardContent>
                          {/* [S]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <div className="inner-sides">
                           <div className="title-area left-area">
                            <div className="txt">3시간 11분</div>
                            <div className="txt-detail">
                              <div className="txt-desc item-txt">
                                보도 13분
                              </div>
                              <div className="txt-desc item-txt">
                                환승 1회
                              </div>
                              <div className="txt-desc item-txt">
                                312.8km
                              </div>
                              {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                            </div>
                          </div>
                            <div className="right-area">
                              <IconButton>
                                <ChevronRight className="bp-icon" />
                              </IconButton>
                            </div>
                          </div>
                          {/* [E]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <Box className="transportation-schedule">
                            <Box className="trip-route-box">
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-error"
                                  aria-label="고속버스"
                                >
                                  <span className="bp-icon icon-bus"></span>
                                </Avatar>
                              </div>
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-success"
                                  aria-label="거래처"
                                >
                                  <PlaceIcon className="bp-icon xsmall" />
                                </Avatar>
                              </div>
                            </Box>
                          </Box>
                          <div className="item-field">
                            <dl className="flex-row-half">
                              <dt className="left-area">
                                <div className="txt">
                                  출발지명이 길어지면 하단으로 2줄처리
                                </div>
                              </dt>
                              <dd className="right-area">
                                <Box className="txt">
                                  도착지명이 길어지면 하단으로 2줄처리
                                </Box>
                              </dd>
                            </dl>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </BasicTabPanel>
                  <BasicTabPanel tabValue={tabValue} index={3}>
                    <div className="bztrip-list">
                      {/* 항공 */}
                      <Card className="item">
                        <CardContent>
                          {/* [S]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <div className="inner-sides">
                           <div className="title-area left-area">
                            <div className="txt">3시간 11분</div>
                            <div className="txt-detail">
                              <div className="txt-desc item-txt">
                                보도 13분
                              </div>
                              <div className="txt-desc item-txt">
                                환승 1회
                              </div>
                              <div className="txt-desc item-txt">
                                312.8km
                              </div>
                              {/* <div className="type-amount item-txt">
                                <div className="number-area">
                                  52,800
                                  <span className="txt-currency">원</span>
                                </div>
                              </div> */}
                            </div>
                          </div>
                            <div className="right-area">
                              <IconButton>
                                <ChevronRight className="bp-icon" />
                              </IconButton>
                            </div>
                          </div>
                          {/* [E]arrow Add 구조 맞춰 변경 20240925 kjs  */}
                          <Box className="transportation-schedule">
                            <Box className="trip-route-box">
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-error"
                                  aria-label="고속버스"
                                >
                                  <span className="bp-icon icon-bus"></span>
                                </Avatar>
                              </div>
                              <div className="item">
                                <Avatar
                                  className="bp-avatar size-xsmall color-success"
                                  aria-label="거래처"
                                >
                                  <PlaceIcon className="bp-icon xsmall" />
                                </Avatar>
                              </div>
                            </Box>
                          </Box>
                          <div className="item-field">
                            <dl className="flex-row-half">
                              <dt className="left-area">
                                <div className="txt">
                                  출발지명이 길어지면 하단으로 2줄처리
                                </div>
                              </dt>
                              <dd className="right-area">
                                <Box className="txt">
                                  도착지명이 길어지면 하단으로 2줄처리
                                </Box>
                              </dd>
                            </dl>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </BasicTabPanel>
                </div>
              </Box>
            </div>
            {/* [E]map-route-wrap */}
          </div>
          {/* [E] */}
        </Paper>
        {/* [E]ui-paper flex-wrap */}
        {/* [S]240819 modify */}
      </LayoutSub>
    </>
  );
};

export default MMA010200;
