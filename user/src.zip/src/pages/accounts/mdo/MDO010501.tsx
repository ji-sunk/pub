import CancelIcon from "@mui/icons-material/Cancel";
import {
  Button,
  IconButton,
  InputAdornment,
  Paper,
  TextField,
} from "@mui/material";
import { Box, Tab, Tabs } from "@mui/material";
import * as React from "react";
import FilterSet from "src/components/common/FilterSet";
import NoData from "src/components/common/NoData";

import { SearchSm } from "@untitled-ui/icons-react";
import { useState } from "react";
import { Helmet as Head } from "react-helmet";
import LayoutSub from "src/templates/layout/LayoutSub";

// tabs
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  tabValue: number;
}

function BasicTabPanel(props: TabPanelProps) {
  const { children, tabValue, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={tabValue !== index}
      id={`basic-tabpanel-${index}`}
      aria-labelledby={`basic-tab-${index}`}
      {...other}
      className="tab-panel"
    >
      {tabValue === index && <div className="panel-inner">{children}</div>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `basic-tab-${index}`,
    "aria-controls": `basic-tabpanel-${index}`,
  };
}
const MDO010501 = () => {
  const [tabValue, setTabValue] = React.useState(0);
  const [checked, setChecked] = useState(false);
  const tabHandleChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  // 상위 컴포넌트에서 하위 탭 데이터와 각 탭에 대한 상태 및 상태 변경 함수 초기화
  const [subTabs, setSubTabs] = useState([
    { label: "용도분할" },
    { label: "사용자분할" },
  ]);

  // 하위 탭 데이터와 각 탭에 대한 상태 및 상태 변경 함수 초기화
  const [subTabStates, setSubTabStates] = useState(
    subTabs.map(() => ({ tabValue: 0 })),
  );

  // 각 하위 탭의 탭 변경 핸들러 함수
  const handleTabChange = (index: number, newValue: number) => {
    setSubTabStates((prevStates) => {
      const newSubTabStates = [...prevStates];
      newSubTabStates[index].tabValue = newValue;
      return newSubTabStates;
    });
  };
  return (
    <>
      <Head>
        <title>영수증 분할</title>
      </Head>
      <LayoutSub>
        {/* [S] defautl : "ui-paper" , flex-wrap receipt-division */}
        <Paper className="ui-paper flex-wrap receipt-division">
          {/* [S] */}
          <div className="light-box full-height">
            {/* [S]receipt-wrap */}
            <div className="receipt-wrap">
              {/* [S]pay-info */}
              <div className="pay-info ui-box">
                <div className="inner-sides">
                  <div className="right-area">
                    <Box className="item-data txt-desc">
                      결제일시 2024.05.12 12:30
                    </Box>
                  </div>
                </div>
                <Box className="usage">
                  대명리조트 울산
                </Box>
                <div className="type-amount">
                  <div className="number-area">
                    <Box className="flex-row">
                      <Box component="span" className="point-large">
                        10,000,000,000
                        <span className="txt-currency">원</span>
                      </Box>
                    </Box>
                  </div>
                </div>
              </div>
              {/* [E]pay-info */}
   
              <div className="divider-top">
                <div className="light-box full-height ui-box">
                  <Box className="bp-tabs tabs-basic tabs-size-medium bp-tabs-top">
                    <Tabs
                      className="tab-list"
                      value={tabValue}
                      onChange={tabHandleChange}
                      aria-label=""
                      TabIndicatorProps={{
                        sx: { backgroundColor: "#00AAD2" },
                      }}
                    >
                      <Tab label="용도분할" {...a11yProps(0)} />
                      <Tab label="사용자분할" {...a11yProps(1)} />
                    </Tabs>

                    <BasicTabPanel tabValue={tabValue} index={0}>
                      <div className="ui-box box-bg-rnd-type">
                        <div className="inner-sides">
                          <div className="left-area">
                            <Box className="icon-subTxt">
                              분할<span>1</span>
                            </Box>
                          </div>
                          <div className="right-area">
                            
                          </div>
                        </div>
                        <div className="item-field">
                          <TextField
                            // onClick={}
                            className="type-search"
                            type="button"
                            defaultValue=""
                            hiddenLabel
                            label="용도"
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <SearchSm
                                    fontSize="medium"
                                    className="bp-icon medium icon-search"
                                  />
                                </InputAdornment>
                              ),
                            }}
                            fullWidth
                          />
                        </div>
                        <div className="item-field">
                          <TextField label="사용금액" placeholder="" fullWidth />
                        </div>
                      </div>
                      
                      <div className="ui-box box-bg-rnd-type">
                        <div className="inner-sides">
                          <div className="left-area">
                            <Box className="icon-subTxt">
                              분할<span>2</span>
                            </Box>
                          </div>
                          <div className="right-area">
                           
                          </div>
                        </div>
                        <div className="item-field">
                          <TextField
                            // onClick={}
                            className="type-search"
                            type="button"
                            defaultValue=""
                            hiddenLabel
                            label="용도"
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <SearchSm
                                    fontSize="medium"
                                    className="bp-icon medium icon-search"
                                  />
                                </InputAdornment>
                              ),
                            }}
                            fullWidth
                          />
                        </div>
                        <div className="item-field">
                          <TextField label="사용금액" placeholder="" fullWidth />
                        </div>
                      </div>

                      <div className="ui-box box-bg-rnd-type">
                        <div className="inner-sides">
                          <div className="left-area">
                            <Box className="icon-subTxt">
                              분할<span>3</span>
                            </Box>
                          </div>
                          <div className="right-area">
                            <IconButton size="small" className="btn-clear">
                              <CancelIcon
                                fontSize="small"
                                className="bp-icon small"
                              />
                            </IconButton>
                          </div>
                        </div>
                        <div className="item-field">
                          <TextField
                            // onClick={}
                            className="type-search"
                            type="button"
                            defaultValue=""
                            hiddenLabel
                            label="용도"
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <SearchSm
                                    fontSize="medium"
                                    className="bp-icon medium icon-search"
                                  />
                                </InputAdornment>
                              ),
                            }}
                            fullWidth
                          />
                        </div>
                        <div className="item-field">
                          <TextField label="사용금액" placeholder="" fullWidth />
                        </div>
                        <div className="color-error">입력하신 금액이 결제비용보다 큽니다.</div>
                      </div>
                    </BasicTabPanel>

                    <BasicTabPanel tabValue={tabValue} index={1}>
                      <div className="ui-box box-bg-rnd-type">
                        <div className="inner-sides">
                          <div className="left-area">
                            <Box className="icon-subTxt">
                              분할<span>1</span>
                            </Box>
                          </div>
                          <div className="right-area">
                            
                          </div>
                        </div>
                        <div className="item-field">
                          <TextField
                            // onClick={}
                            className="type-search"
                            type="button"
                            defaultValue=""
                            hiddenLabel
                            label="용도"
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <SearchSm
                                    fontSize="medium"
                                    className="bp-icon medium icon-search"
                                  />
                                </InputAdornment>
                              ),
                            }}
                            fullWidth
                          />
                        </div>
                        <div className="item-field">
                          <TextField label="사용금액" placeholder="" fullWidth />
                        </div>
                      </div>
                      
                      <div className="ui-box box-bg-rnd-type">
                        <div className="inner-sides">
                          <div className="left-area">
                            <Box className="icon-subTxt">
                              분할<span>2</span>
                            </Box>
                          </div>
                          <div className="right-area">
                           
                          </div>
                        </div>
                        <div className="item-field">
                          <TextField
                            // onClick={}
                            className="type-search"
                            type="button"
                            defaultValue=""
                            hiddenLabel
                            label="용도"
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <SearchSm
                                    fontSize="medium"
                                    className="bp-icon medium icon-search"
                                  />
                                </InputAdornment>
                              ),
                            }}
                            fullWidth
                          />
                        </div>
                        <div className="item-field">
                          <TextField label="사용금액" placeholder="" fullWidth />
                        </div>
                      </div>

                      <div className="ui-box box-bg-rnd-type">
                        <div className="inner-sides">
                          <div className="left-area">
                            <Box className="icon-subTxt">
                              분할<span>3</span>
                            </Box>
                          </div>
                          <div className="right-area">
                            <IconButton size="small" className="btn-clear">
                              <CancelIcon
                                fontSize="small"
                                className="bp-icon small"
                              />
                            </IconButton>
                          </div>
                        </div>
                        <div className="item-field">
                          <TextField
                            // onClick={}
                            className="type-search"
                            type="button"
                            defaultValue=""
                            hiddenLabel
                            label="용도"
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <SearchSm
                                    fontSize="medium"
                                    className="bp-icon medium icon-search"
                                  />
                                </InputAdornment>
                              ),
                            }}
                            fullWidth
                          />
                        </div>
                        <div className="item-field">
                          <TextField label="사용금액" placeholder="" fullWidth />
                        </div>
                        {/* <div className="color-error">입력하신 금액이 결제비용보다 큽니다.</div> */}
                      </div>
                    </BasicTabPanel>
                  </Box>
                </div>
              </div>
            </div>
            {/* [E] receipt-wrap */}
          </div>
        </Paper>
        {/* [E]ui-paper flex-wrap */}
        <Box className="btns-group">
          <Box className="inner">
            <Button
              variant="contained"
              size="large"
              className="btn-xlarge color-neutral"
            >
              취소
            </Button>
            <Button variant="contained" size="large" className="btn-xlarge">
              영수증 분할
            </Button>
          </Box>
        </Box>
      </LayoutSub>
    </>
  );
};

export default MDO010501;
